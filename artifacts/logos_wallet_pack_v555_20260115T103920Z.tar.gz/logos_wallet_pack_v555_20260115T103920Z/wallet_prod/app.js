(function(){
  const $ = (id) => document.getElementById(id);

  function setStatus(t){ const el=$("status"); if(el) el.textContent = t || ""; }
  function setNetBadge(ok){
    const el = $("netBadge");
    if (!el) return;
    el.className = "muted " + (ok ? "badge-ok" : "badge-bad");
    el.textContent = ok ? "live" : "offline";
  }

  function readRID(){
    try{
      return (localStorage.getItem("RID") || localStorage.getItem("logos_rid") || "").trim();
    }catch(e){ return ""; }
  }

  function devMode(){
    try { return localStorage.getItem("logos_dev") === "1"; } catch(e){ return false; }

  function clearSessionPass(){
    try{
      sessionStorage.removeItem("PASS");
      sessionStorage.removeItem("logos_pass");
    }catch(e){}
  }
  }

  function fmtLgnFromMicro(micro){
    const s = String(micro);
    const neg = s.startsWith("-");
    const a = neg ? s.slice(1) : s;
    const pad = a.padStart(7, "0");
    const intPart = pad.slice(0, -6);
    const frac = pad.slice(-6);
    return (neg ? "-" : "") + intPart + "." + frac;
  }

  function shortRid(rid){
    if (!rid) return "—";
    if (rid.length <= 18) return rid;
    return rid.slice(0,10) + "…" + rid.slice(-6);
  }

  async function jfetch(url, opts){
    const t0 = performance.now();
    const r = await fetch(url, Object.assign({ cache: "no-store" }, opts||{}));
    const t1 = performance.now();
    return { r, ms: Math.round(t1 - t0) };
  }

  function escapeHtml(s){
    return String(s)
      .replaceAll("&","&amp;")
      .replaceAll("<","&lt;")
      .replaceAll(">","&gt;")
      .replaceAll('"',"&quot;")
      .replaceAll("'","&#039;");
  }

  function copyText(t){
    try{ navigator.clipboard.writeText(String(t||"")); setStatus("OK: copied."); }
    catch(e){ setStatus("ERR: copy failed."); }
  }

  function mkLine(container, title, value, copyValue){
    const row = document.createElement("div");
    row.className = "kv";
    row.innerHTML = `
      <div>
        <div class="k">${escapeHtml(title)}</div>
        <div class="v">${escapeHtml(value || "—")}</div>
      </div>
      <button class="btn small">Copy</button>
    `;
    row.querySelector("button").addEventListener("click", () => copyText(copyValue ?? value ?? ""));
    container.appendChild(row);
  }

  function renderReceive(container, addresses){
    container.innerHTML = "";
    if (!addresses || typeof addresses !== "object"){
      container.innerHTML = '<div class="muted">Нет адресов.</div>';
      return;
    }
    // order: BTC, ETH, TRON, USDT_ERC20, USDT_TRC20
    const order = ["BTC","ETH","TRON","USDT_ERC20","USDT_TRC20"];
    for (const k of order){
      if (addresses[k]){
        const title =
          k === "USDT_ERC20" ? "USDT (ERC20)" :
          k === "USDT_TRC20" ? "USDT (TRC20)" :
          k;
        mkLine(container, title, addresses[k], addresses[k]);
      }
    }
  }

  function satToBtc(sat){ return (Number(sat||0) / 1e8).toFixed(8).replace(/\.?0+$/,''); }
  function formatNum(x){
    if (x == null) return "0";
    const n = Number(x);
    if (!isFinite(n)) return String(x);
    return String(n);
  }

  function renderExternal(container, j){
    container.innerHTML = "";
    if (!j || typeof j !== "object"){
      container.innerHTML = '<div class="muted">Нет данных.</div>';
      return;
    }

    const b = j.balances || {};
    // BTC
    if (b.BTC && typeof b.BTC === "object"){
      const sat = (b.BTC.total_sat ?? b.BTC.confirmed_sat ?? b.BTC.confirmed ?? 0);
      const btc = (b.BTC.total_btc != null) ? formatNum(b.BTC.total_btc) : satToBtc(sat);
      mkLine(container, "BTC balance", btc + " BTC", btc);
    } else {
      mkLine(container, "BTC balance", "0 BTC", "0");
    }

    // ETH + USDT ERC20
    if (b.ETH && typeof b.ETH === "object"){
      const eth = (b.ETH.eth != null) ? formatNum(b.ETH.eth) : (b.ETH.wei != null ? (Number(b.ETH.wei)/1e18) : 0);
      mkLine(container, "ETH balance", formatNum(eth) + " ETH", String(eth));
      if (b.ETH.usdt_erc20 && typeof b.ETH.usdt_erc20 === "object"){
        const u = b.ETH.usdt_erc20.usdt ?? 0;
        mkLine(container, "USDT (ERC20) balance", formatNum(u) + " USDT", String(u));
      }
    } else {
      mkLine(container, "ETH balance", "0 ETH", "0");
      mkLine(container, "USDT (ERC20) balance", "0 USDT", "0");
    }

    // TRON + USDT TRC20
    if (b.TRON && typeof b.TRON === "object"){
      const trx = (b.TRON.trx != null) ? formatNum(b.TRON.trx) : (b.TRON.sun != null ? (Number(b.TRON.sun)/1e6) : 0);
      mkLine(container, "TRX balance", formatNum(trx) + " TRX", String(trx));
      if (b.TRON.usdt_trc20 && typeof b.TRON.usdt_trc20 === "object"){
        const u = b.TRON.usdt_trc20.usdt ?? 0;
        mkLine(container, "USDT (TRC20) balance", formatNum(u) + " USDT", String(u));
      }
    } else {
      mkLine(container, "TRX balance", "0 TRX", "0");
      mkLine(container, "USDT (TRC20) balance", "0 USDT", "0");
    }

    // latency
    if (j.latency_ms != null){
      mkLine(container, "wallet-api latency", String(j.latency_ms) + " ms", String(j.latency_ms));
    }
  }

  async function refreshAll(){
    const rid = readRID();
    if (!rid){
      setStatus("ERR: RID не найден. Зайди через auth.html");
      try{ location.href = "./auth.html"; }catch(e){}
      return;
    }

    const API_BASE = window.API_BASE || "/api";
    const WALLET_API = window.WALLET_API || "/wallet-api";

    if ($("api")) $("api").textContent = API_BASE;
    if ($("rid")) $("rid").value = rid;
    if ($("topRid")) $("topRid").textContent = shortRid(rid);

    // 1) node balance
    try{
      const { r, ms } = await jfetch(API_BASE + "/balance/" + encodeURIComponent(rid));
      if ($("lat")) $("lat").textContent = ms + " ms";
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();

      const micro = (j && j.balance != null) ? j.balance : 0;
      if ($("balLgn")) $("balLgn").textContent = fmtLgnFromMicro(micro);
      if ($("balMicro")) $("balMicro").textContent = String(micro) + " micro-LGN";
      if ($("nonce")) $("nonce").textContent = (j && j.nonce != null) ? String(j.nonce) : "—";
      if ($("rawNode")) $("rawNode").textContent = JSON.stringify(j, null, 2);
      if ($("topBal")) $("topBal").textContent = fmtLgnFromMicro(micro);

      setNetBadge(true);
      setStatus("OK: обновлено.");
    }catch(e){
      setNetBadge(false);
      setStatus("ERR node-api: " + (e && e.message ? e.message : String(e)));
    }

    // 2) wallet receive
    try{
      const { r } = await jfetch(WALLET_API + "/v1/receive/" + encodeURIComponent(rid));
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();

      if ($("rawRecv")) $("rawRecv").textContent = JSON.stringify(j, null, 2);
      renderReceive($("recvBox"), j.addresses || {});
    }catch(e){
      if ($("rawRecv")) $("rawRecv").textContent = "";
      if ($("recvBox")) $("recvBox").innerHTML = '<div class="muted">ERR wallet-api receive: ' + escapeHtml(e.message||String(e)) + '</div>';
    }

    // 3) wallet balances
    try{
      const { r } = await jfetch(WALLET_API + "/v1/balances/" + encodeURIComponent(rid));
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();

      if ($("rawExt")) $("rawExt").textContent = JSON.stringify(j, null, 2);
      renderExternal($("extBalBox"), j);
    }catch(e){
      if ($("rawExt")) $("rawExt").textContent = "";
      if ($("extBalBox")) $("extBalBox").innerHTML = '<div class="muted">ERR wallet-api balances: ' + escapeHtml(e.message||String(e)) + '</div>';
    }
  }

  function setTab(name){
    document.querySelectorAll(".tab").forEach(t => {
      t.classList.toggle("active", t.dataset.tab === name);
    });
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    const panel = document.getElementById("panel-" + name);
    if (panel) panel.classList.add("active");
    try{ location.hash = name; }catch(e){}
  }

  function uuid(){
    const b = crypto.getRandomValues(new Uint8Array(16));
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = [...b].map(x => x.toString(16).padStart(2,"0")).join("");
    return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
  }

  async function doTopup(){
    const rid = readRID();
    const net = $("topNetwork") ? ($("topNetwork").value || "ETH") : "ETH";
    const box = $("topupBox");
    const st = $("topupStatus");
    if (st) st.textContent = "request…";
    if (box) box.innerHTML = "";

    try{
      const body = { rid, token:"USDT", network: net };
      const { r } = await jfetch((window.WALLET_API||"/wallet-api") + "/v1/topup/request", {
        method:"POST",
        headers:{ "content-type":"application/json" },
        body: JSON.stringify(body)
      });
      const j = await r.json().catch(()=>({}));
      if (!r.ok) throw new Error("HTTP " + r.status + ": " + JSON.stringify(j));
      if (st) st.textContent = "OK";

      if (box){
        box.innerHTML = "";
        if (j.address) mkLine(box, "Topup address", j.address, j.address);
        if (j.network) mkLine(box, "Network", j.network, j.network);
        if (j.token) mkLine(box, "Token", j.token, j.token);
      }
    }catch(e){
      if (st) st.textContent = "ERR: " + (e.message||String(e));
    }
  }

  async function doQuote(){
    const st = $("qStatus"), pre = $("qRaw");
    if (st) st.textContent = "request…";
    if (pre) pre.textContent = "";
    try{
      const body = {
        from_token: ($("qFrom")?.value || "").trim(),
        to_token: ($("qTo")?.value || "").trim(),
        amount: parseInt(($("qAmount")?.value || "0").trim(), 10)
      };
      const { r } = await jfetch((window.WALLET_API||"/wallet-api") + "/v1/quote", {
        method:"POST",
        headers:{ "content-type":"application/json" },
        body: JSON.stringify(body)
      });
      const j = await r.json().catch(()=>({}));
      if (!r.ok) throw new Error("HTTP " + r.status + ": " + JSON.stringify(j));
      if (st) st.textContent = "OK";
      if (pre) pre.textContent = JSON.stringify(j, null, 2);
    }catch(e){
      if (st) st.textContent = "ERR: " + (e.message||String(e));
    }
  }

  async function doWithdraw(){
    const rid = readRID();
    const net = $("wdNetwork") ? ($("wdNetwork").value || "ETH") : "ETH";
    const amt = parseInt(($("wdAmount")?.value || "0").trim(), 10);
    const to = ($("wdTo")?.value || "").trim();

    const st = $("wdStatus"), pre = $("wdRaw");
    if (st) st.textContent = "request…";
    if (pre) pre.textContent = "";

    try{
      const body = {
        rid,
        token: "USDT",
        network: net,
        amount: amt,
        to_address: to,
        request_id: uuid()
      };
      const { r } = await jfetch((window.WALLET_API||"/wallet-api") + "/v1/withdraw", {
        method:"POST",
        headers:{ "content-type":"application/json" },
        body: JSON.stringify(body)
      });
      const j = await r.json().catch(()=>({}));
      if (!r.ok) throw new Error("HTTP " + r.status + ": " + JSON.stringify(j));
      if (st) st.textContent = "OK";
      if (pre) pre.textContent = JSON.stringify(j, null, 2);
    }catch(e){
      if (st) st.textContent = "ERR: " + (e.message||String(e));
    }
  }

  window.addEventListener("DOMContentLoaded", () => {
    // hide raw blocks for normal users
    if (!devMode()){
      document.querySelectorAll("details").forEach(d => d.style.display = "none");
    }

    document.querySelectorAll(".tab").forEach(t => {
      t.addEventListener("click", () => setTab(t.dataset.tab));
    });
    const start = (location.hash||"").replace("#","") || "assets";
    setTab(start);

    $("btnCopyRid")?.addEventListener("click", () => copyText($("rid")?.value || ""));
    $("btnRefresh")?.addEventListener("click", refreshAll);

    $("btnLogout")?.addEventListener("click", () => {
      try{ localStorage.removeItem("PASS"); localStorage.removeItem("logos_pass"); }catch(e){}
      location.href = "./auth.html";
    });

    $("btnTopup")?.addEventListener("click", doTopup);
    $("btnQuote")?.addEventListener("click", doQuote);

    $("btnWithdraw")?.addEventListener("click", doWithdraw);
    $("btnWithdrawClear")?.addEventListener("click", () => {
      if ($("wdAmount")) $("wdAmount").value = "";
      if ($("wdTo")) $("wdTo").value = "";
      if ($("wdStatus")) $("wdStatus").textContent = "";
      if ($("wdRaw")) $("wdRaw").textContent = "";
    });

    $("btnShowLocal")?.addEventListener("click", () => {
      const rid = readRID();
      if ($("setStatus")) $("setStatus").textContent = rid ? ("RID: " + rid) : "RID не найден.";
    });
    $("btnClearLocal")?.addEventListener("click", () => {
      try{
        localStorage.removeItem("RID");
        localStorage.removeItem("logos_rid");
        localStorage.removeItem("PASS");
        localStorage.removeItem("logos_pass");
      }catch(e){}
      if ($("setStatus")) $("setStatus").textContent = "OK: local keys cleared";
    });

    refreshAll();
  });

  window._logos_refreshAll = refreshAll;
})();

/* ========= BRIDGE MODULE (v1) ========= */
(() => {
  function ridGet(){
    return (
      localStorage.getItem("RID") ||
      localStorage.getItem("logos_rid") ||
      sessionStorage.getItem("RID") ||
      sessionStorage.getItem("logos_rid") ||
      ""
    );
  }

  function apiBase(){
    // wallet-api (FastAPI proxy)
    return (window.LOGOS_WALLET_API || window.WALLET_API || (window.location.origin.replace(/\/+$/, "") + "/wallet-api"));
  }

  function esc(s){
    return String(s ?? "").replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function q(sel, root=document){ return root.querySelector(sel); }

  function setMsg(root, text, ok=true){
    const el = q(".bridgeMsg", root);
    if (!el) return;
    el.textContent = text || "";
    el.style.opacity = text ? "1" : "0";
    el.style.color = ok ? "" : "#ff6b6b";
  }

  async function postJSON(url, body){
    const r = await fetch(url, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body || {})
    });
    const t = await r.text();
    let j = null;
    try { j = JSON.parse(t); } catch(e) {}
    if (!r.ok){
      const msg = (j && (j.detail || j.error)) ? JSON.stringify(j) : (t || ("HTTP " + r.status));
      throw new Error(msg);
    }
    return j ?? {};
  }

  function shortRID(rid){
    if (!rid) return "";
    if (rid.length <= 18) return rid;
    return rid.slice(0, 10) + "…" + rid.slice(-6);
  }

  function genReqId(){
    return "w_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2,10);
  }

  function renderBridge(){
    const panel = document.getElementById("panel-bridge");
    const root = document.getElementById("bridgeRoot");
    if (!panel || !root) return;

    // прячем старое/случайное содержимое панели, оставляем только bridgeRoot
    try{
      [...panel.children].forEach(ch => { if (ch !== root) ch.style.display = "none"; });
    }catch(e){}

    const rid = ridGet();
    root.innerHTML = `
      <div class="card">
        <div class="h">Bridge</div>
        <div class="muted">Обмен/ввод/вывод через wallet-api. Для обычных людей — без сырого текста.</div>
        <div style="height:10px"></div>
        <div class="bridgeMsg muted" style="opacity:0; transition:.2s;"></div>
      </div>

      <div class="card">
        <div class="h">Quote</div>
        <div class="muted">Расчёт курса (без отправки транзакции).</div>
        <div style="height:12px"></div>

        <div class="row" style="display:flex; gap:10px; flex-wrap:wrap;">
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">From</div>
            <input class="mono" id="qFrom" value="USDT" />
          </div>
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">To</div>
            <input class="mono" id="qTo" value="LGN" />
          </div>
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Amount</div>
            <input class="mono" id="qAmt" value="100" />
          </div>
        </div>

        <div style="height:12px"></div>
        <button class="btn" id="btnQuote">Get quote</button>

        <div style="height:10px"></div>
        <div class="muted" id="quoteOut" style="white-space:pre-wrap;"></div>
      </div>

      <div class="card">
        <div class="h">Top up</div>
        <div class="muted">Получить адрес для пополнения (USDT).</div>
        <div style="height:12px"></div>

        <div class="row" style="display:flex; gap:10px; flex-wrap:wrap;">
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Network</div>
            <select class="mono" id="tuNet">
              <option value="ETH" selected>ETH</option>
            </select>
          </div>
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Token</div>
            <select class="mono" id="tuTok">
              <option value="USDT" selected>USDT</option>
            </select>
          </div>
        </div>

        <div style="height:12px"></div>
        <button class="btn" id="btnTopup">Get deposit address</button>

        <div style="height:12px"></div>
        <div class="muted">Address</div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
          <input class="mono" id="tuAddr" readonly value="" style="flex:1; min-width:260px;" />
          <button class="btn" id="btnCopyTopup" type="button">Copy</button>
        </div>
      </div>

      <div class="card">
        <div class="h">Withdraw</div>
        <div class="muted">Вывод USDT (тестовая ручка, если включена на сервере).</div>
        <div style="height:12px"></div>

        <div class="row" style="display:flex; gap:10px; flex-wrap:wrap;">
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Network</div>
            <select class="mono" id="wdNet">
              <option value="ETH" selected>ETH</option>
            </select>
          </div>
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Token</div>
            <select class="mono" id="wdTok">
              <option value="USDT" selected>USDT</option>
            </select>
          </div>
          <div style="flex:1; min-width:200px;">
            <div class="muted" style="margin-bottom:6px;">Amount</div>
            <input class="mono" id="wdAmt" value="1" />
          </div>
        </div>

        <div style="height:10px"></div>
        <div class="muted" style="margin-bottom:6px;">To address</div>
        <input class="mono" id="wdTo" value="" placeholder="0x... or T..." />

        <div style="height:12px"></div>
        <button class="btn" id="btnWithdraw">Withdraw</button>

        <div style="height:10px"></div>
        <div class="muted" id="wdOut" style="white-space:pre-wrap;"></div>
      </div>
    `;

    // handlers
    q("#btnQuote", root).addEventListener("click", async () => {
      try{
        setMsg(root, "Запрашиваю quote…");
        const from = q("#qFrom", root).value.trim();
        const to   = q("#qTo", root).value.trim();
        const amt  = parseInt(q("#qAmt", root).value.trim() || "0", 10);

        const data = await postJSON(apiBase() + "/v1/quote", {from_token: from, to_token: to, amount: amt});
        q("#quoteOut", root).textContent = `price: ${data.price}\nexpected_out: ${data.expected_out}`;
        setMsg(root, "OK: quote готов ✅");
      }catch(e){
        setMsg(root, "ERR: " + (e?.message || e), false);
      }
    });

    q("#btnTopup", root).addEventListener("click", async () => {
      try{
        if (!rid) throw new Error("RID не найден в localStorage");
        setMsg(root, "Запрашиваю адрес пополнения…");
        const network = q("#tuNet", root).value;
        const token   = q("#tuTok", root).value;
        const data = await postJSON(apiBase() + "/v1/topup/request", {rid, network, token});
        q("#tuAddr", root).value = data.address || "";
        setMsg(root, "OK: адрес получен ✅");
      }catch(e){
        setMsg(root, "ERR: " + (e?.message || e), false);
      }
    });

    q("#btnCopyTopup", root).addEventListener("click", async () => {
      const v = q("#tuAddr", root).value;
      if (!v) return;
      try{ await navigator.clipboard.writeText(v); setMsg(root, "Скопировано ✅"); }
      catch(e){ setMsg(root, "Не смог скопировать (браузер).", false); }
    });

    q("#btnWithdraw", root).addEventListener("click", async () => {
      try{
        if (!rid) throw new Error("RID не найден в localStorage");
        const network = q("#wdNet", root).value;
        const token   = q("#wdTok", root).value;
        const amount  = parseInt(q("#wdAmt", root).value.trim() || "0", 10);
        const to_address = q("#wdTo", root).value.trim();
        if (!to_address) throw new Error("Укажи to_address");
        const request_id = genReqId();

        setMsg(root, "Отправляю withdraw…");
        const data = await postJSON(apiBase() + "/v1/withdraw", {rid, network, token, amount, to_address, request_id});
        q("#wdOut", root).textContent = data ? JSON.stringify(data, null, 2) : "OK";
        setMsg(root, "OK: withdraw запрос отправлен ✅");
      }catch(e){
        setMsg(root, "ERR: " + (e?.message || e), false);
      }
    });

    // верхняя шапка (чисто подсказка, не ломаем существующую)
    try{
      const top = document.querySelector(".topbar") || document.body;
      // ничего не трогаем, просто подсказка в сообщении
      setMsg(root, rid ? ("RID: " + shortRID(rid)) : "RID не найден", true);
    }catch(e){}
  }

  function initBridge(){
    const tab = document.querySelector('.tab[data-tab="bridge"]');
    const panel = document.getElementById("panel-bridge");
    const root = document.getElementById("bridgeRoot");
    if (!panel || !root) return;

    // рендерим при первом клике на вкладку
    if (tab && !tab.__bridgeBound){
      tab.__bridgeBound = true;
      tab.addEventListener("click", () => {
        try{ renderBridge(); }catch(e){}
      });
    }

    // если панель уже активна — рендерим сразу
    try{
      if (panel.style.display !== "none") renderBridge();
    }catch(e){}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initBridge);
  } else {
    initBridge();
  }
})();



/* ========= SEND LGN MODULE (v2, sig_hex) ========= */
(() => {
  const NODE_API = (window.LOGOS_NODE_API || "/api").replace(/\/+$/,"");

  function q(sel, root=document){ return root.querySelector(sel); }
  function qa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

  function utf8(s){ return new TextEncoder().encode(String(s)); }

  function hex(u8){
    let out = "";
    for (let i=0;i<u8.length;i++){
      out += u8[i].toString(16).padStart(2,"0");
    }
    return out;
  }

  function hexToU8(h){
    h = (h||"").trim().replace(/^0x/,"");
    if (!h || (h.length % 2)) return null;
    const u = new Uint8Array(h.length/2);
    for (let i=0;i<u.length;i++) u[i] = parseInt(h.substr(i*2,2),16);
    return u;
  }

  function getRID(){
    return localStorage.getItem("RID")
      || localStorage.getItem("logos_rid")
      || localStorage.getItem("logos_last_rid")
      || sessionStorage.getItem("RID")
      || "";
  }

  // пытаемся найти private Ed25519 JWK в localStorage (если ключи хранятся так)
  function findEd25519PrivJwk(){
    for (let i=0;i<localStorage.length;i++){
      const k = localStorage.key(i);
      if (!k) continue;
      const v = localStorage.getItem(k);
      if (!v || v.length < 20) continue;
      try{
        const j = JSON.parse(v);
        if (j && j.crv === "Ed25519" && j.kty && j.d && j.x) return j;
      }catch(e){}
    }
    return null;
  }

  async function importPrivKeyFromJwk(jwk){
    return crypto.subtle.importKey("jwk", jwk, {name:"Ed25519"}, false, ["sign"]);
  }

  async function signEd25519(privKey, msgU8){
    const sig = await crypto.subtle.sign({name:"Ed25519"}, privKey, msgU8);
    return new Uint8Array(sig);
  }

  async function getNonce(rid){
    const r = await fetch(`${NODE_API}/balance/${encodeURIComponent(rid)}`);
    if(!r.ok) throw new Error(`balance http ${r.status}`);
    const j = await r.json();
    return j.nonce;
  }

  async function getCanonBytes(draft){
    // пробуем debug_canon (если включен на сервере)
    try{
      const r = await fetch(`${NODE_API}/debug_canon`, {
        method:"POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(draft)
      });
      if (r.ok){
        const t = await r.text();
        // варианты: JSON или просто строка
        try{
          const j = JSON.parse(t);
          const ch = j.canon_hex || j.canon || j.msg_hex || j.message_hex || j.bytes_hex || "";
          const u = hexToU8(ch);
          if (u) return u;
          const s = (j.canon_str || j.message || j.msg || "");
          if (s) return utf8(s);
        }catch(e){
          // если просто строка
          const u = hexToU8(t);
          if (u) return u;
          if (t && t.length) return utf8(t);
        }
      }
    }catch(e){}

    // fallback: стабильная строка (если debug_canon нет)
    const memo = (draft.memo === null || draft.memo === undefined) ? "" : String(draft.memo);
    const s = `LOGOS_TX|from=${draft.from}|to=${draft.to}|amount=${draft.amount}|nonce=${draft.nonce}|memo=${memo}`;
    return utf8(s);
  }

  function setStatus(panel, text, ok=true){
    let el = q(".sendStatus", panel);
    if(!el){
      el = document.createElement("div");
      el.className = "sendStatus";
      el.style.marginTop = "10px";
      el.style.fontSize = "13px";
      el.style.opacity = "0.95";
      panel.appendChild(el);
    }
    el.textContent = text || "";
    el.style.color = ok ? "" : "#ff6b6b";
  }

  function findSendPanel(){
    return document.getElementById("panel-send")
      || document.getElementById("panel-transfer")
      || document.querySelector('.panel[data-panel="send"]')
      || null;
  }

  function findSendControls(panel){
      const btnSend = qa("button", panel).find(b => (b.textContent||"").toLowerCase().includes("send lgn"));
      const btnFillMe = qa("button", panel).find(b => (b.textContent||"").toLowerCase().includes("мой rid"));

      // ВАЖНО: не по индексу, а по id (иначе withdraw inputs ломают логику)
      const toRid  = document.getElementById("lgnTo") || document.getElementById("lgmTo") || null;
      const amount = document.getElementById("lgnAmount") || document.getElementById("lgmAmount") || null;

      // memo optional
      const memo = document.getElementById("lgnMemo") || document.getElementById("lgmMemo") || null;

      return {btnSend, btnFillMe, toRid, amount, memo};
    }

  async function handleSend(panel, ui){
    const fromRid = getRID();
    const toRid = (ui.toRid?.value || "").trim();
    const memoStr = (ui.memo?.value || "").trim();
    const amtStr = (ui.amount?.value || "").trim();

    if(!fromRid){ setStatus(panel, "ERR: нет RID (ключи не найдены).", false); return; }
    if(!toRid || toRid.length < 10){ setStatus(panel, "ERR: введи RID получателя.", false); return; }

    const amt = Number(amtStr.replace(",", "."));
    if(!isFinite(amt) || amt <= 0){ setStatus(panel, "ERR: введи сумму > 0.", false); return; }

    const amount_mic = Math.round(amt * 1e6);

    setStatus(panel, "Отправляю…", true);

    let nonce;
    try{
      nonce = await getNonce(fromRid);
    }catch(e){
      setStatus(panel, "ERR: не смог получить nonce (balance).", false);
      return;
    }

    // draft по схеме TxIn (без подписи)
    const draft = {
      from: fromRid,
      to: toRid,
      amount: amount_mic,
      nonce: nonce,
      memo: memoStr ? memoStr : None
    };

    // JS не знает None, поэтому:
    if (!memoStr) draft.memo = null;

    // bytes for signing
    const canonBytes = await getCanonBytes(draft);

    // signer
    const jwk = findEd25519PrivJwk();
    if(!jwk){
      setStatus(panel, "ERR: приватный ключ не найден (localStorage). Если ключи в IndexedDB — скажи, сделаем доступ через существующий signer.", false);
      return;
    }

    let privKey;
    try{
      privKey = await importPrivKeyFromJwk(jwk);
    }catch(e){
      setStatus(panel, "ERR: не смог импортировать Ed25519 ключ.", false);
      return;
    }

    let sigU8;
    try{
      sigU8 = await signEd25519(privKey, canonBytes);
    }catch(e){
      setStatus(panel, "ERR: не смог подписать транзакцию.", false);
      return;
    }

    const txIn = {
      from: draft.from,
      to: draft.to,
      amount: draft.amount,
      nonce: draft.nonce,
      memo: draft.memo,
      sig_hex: hex(sigU8)
    };

    try{
      const r = await fetch(`${NODE_API}/submit_tx`, {
        method:"POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(txIn)
      });
      const text = await r.text();
      if(!r.ok){
        setStatus(panel, `ERR submit_tx: ${r.status} ${text}`.slice(0,500), false);
        return;
      }
      try{
        const j = JSON.parse(text);
        if (j && j.ok){
          setStatus(panel, `✅ Отправлено. txid: ${(j.txid||"")}`.trim(), true);
        } else {
          setStatus(panel, `⚠️ Ответ: ${text}`.slice(0,500), false);
        }
      }catch(e){
        setStatus(panel, `✅ Отправлено. Ответ: ${text}`.slice(0,200), true);
      }
    }catch(e){
      setStatus(panel, "ERR: сеть/submit_tx не доступен.", false);
    }
  }

  function initSend(){
    const panel = findSendPanel();
    if(!panel) return;
    const ui = findSendControls(panel);

    if(ui.btnFillMe){
      ui.btnFillMe.addEventListener("click", () => {
        const rid = getRID();
        if(ui.toRid) ui.toRid.value = rid || "";
      });
    }
    if(ui.btnSend){
      ui.btnSend.addEventListener("click", () => handleSend(panel, ui));
    }
  }

  try{ initSend(); }catch(e){}
})();

