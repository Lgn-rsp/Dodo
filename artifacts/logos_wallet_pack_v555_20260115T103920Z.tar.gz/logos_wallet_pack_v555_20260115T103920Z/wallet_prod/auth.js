(() => {
  const LS_VAULT = "logos_vault_v1";
  const SS_SEED  = "logos_sk_seed_b64";     // sessionStorage (seed32)
  const LS_LAST  = "logos_last_rid";
  const LS_RID1  = "RID";
  const LS_RID2  = "logos_rid";

  const $ = (id) => document.getElementById(id);

  

  // --- BIP39 (local, offline): use window.bip39lite ---
  function BIP39(){
    const b = window.bip39lite;
    if(!b) throw new Error("BIP39 not loaded: check vendor/wordlist_en.js + vendor/bip39_lite.js in auth.html");
    return b;
  }
  const show = (id) => $(id).style.display = "";
  const hide = (id) => $(id).style.display = "none";
  const go = (id) => {
    ["step0","mnemonicSection","confirmSection","setPassSection","restoreSection","unlockSection"].forEach(hide);
    show(id);
  };

  function status(el, ok, msg){
    el.textContent = msg || "";
    el.className = ok ? "status ok" : "status err";
  }

  function norm(s){ return (s||"").toLowerCase().trim().replace(/\s+/g," "); }

  function u8ToB64(u8){
    let s=""; u8.forEach(b=>s+=String.fromCharCode(b));
    return btoa(s);
  }
  function b64ToU8(b64){
    const s = atob(b64);
    const u8 = new Uint8Array(s.length);
    for(let i=0;i<s.length;i++) u8[i]=s.charCodeAt(i);
    return u8;
  }

  async function sha256(u8){
    const h = await crypto.subtle.digest("SHA-256", u8);
    return new Uint8Array(h);
  }

  async function pbkdf2Key(password, saltU8){
    const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey(
      {name:"PBKDF2", salt:saltU8, iterations:210000, hash:"SHA-256"},
      base,
      {name:"AES-GCM", length:256},
      false,
      ["encrypt","decrypt"]
    );
  }

  async function encryptSeed32(seed32, password){
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv   = crypto.getRandomValues(new Uint8Array(12));
    const key  = await pbkdf2Key(password, salt);
    const ctBuf = await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, seed32);
    return { salt:u8ToB64(salt), iv:u8ToB64(iv), ct:u8ToB64(new Uint8Array(ctBuf)) };
  }

  async function decryptSeed32(vault, password){
    const salt = b64ToU8(vault.salt);
    const iv   = b64ToU8(vault.iv);
    const ct   = b64ToU8(vault.ct);
    const key  = await pbkdf2Key(password, salt);
    const ptBuf = await crypto.subtle.decrypt({name:"AES-GCM", iv}, key, ct);
    return new Uint8Array(ptBuf);
  }

  // Base58 (fallback RID derivation)
  function base58(u8){
    const A = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    let x = 0n;
    for (const b of u8) x = (x<<8n) + BigInt(b);
    let out = "";
    while (x > 0n) {
      const mod = x % 58n;
      out = A[Number(mod)] + out;
      x = x / 58n;
    }
    return out || "1";
  }

  function makeRIDFromPub(pubU8){
    // если где-то есть ваш канон — используем его
    if (typeof window.ridFromPub === "function") return window.ridFromPub(pubU8);
    if (typeof window.makeRID === "function") return window.makeRID(pubU8);
    // fallback формат похожий на текущие Atx...
    return "Atx" + base58(pubU8).slice(0, 44);
  }

  function setRidSession(rid){
    rid = (rid||"").trim();
    if (!rid) return;
    localStorage.setItem(LS_RID1, rid);
    localStorage.setItem(LS_RID2, rid);
    localStorage.setItem(LS_LAST, rid);
    $("rid").value = rid;
  }

  function goWallet(){
    location.href = "./app.html#assets";
  }

  // ---------- Create flow ----------
  let mnemonic = "";

  // --- Premium seed renderer (chips + copy/hide) ---
  function renderSeed(wordsArr){
    const el = $("mnemonicShow");
    if(!el) return;
    el.innerHTML = wordsArr.map((w,i)=>(
      `<div class="seedWord"><div class="seedNum">${i+1}</div><div class="seedText">${w}</div></div>`
    )).join("");
    // default visible
    el.classList.remove("isHidden");
    const b = $("btnSeedHide");
    if (b) b.textContent = "Скрыть";
  }

  function bindSeedActions(){
    const btnCopy = $("btnSeedCopy");
    if (btnCopy && !btnCopy.__bound){
      btnCopy.__bound = true;
      btnCopy.addEventListener("click", async ()=>{
        try{
          if(!mnemonic) return;
          await navigator.clipboard.writeText(mnemonic);
          btnCopy.textContent = "Скопировано";
          setTimeout(()=>btnCopy.textContent="Copy", 900);
        }catch(e){
          console.warn("copy failed", e);
          btnCopy.textContent = "Не удалось";
          setTimeout(()=>btnCopy.textContent="Copy", 900);
        }
      });
    }

    const btnHide = $("btnSeedHide");
    if (btnHide && !btnHide.__bound){
      btnHide.__bound = true;
      btnHide.addEventListener("click", ()=>{
        const el = $("mnemonicShow");
        if(!el) return;
        const on = !el.classList.contains("isHidden");
        el.classList.toggle("isHidden", on);
        btnHide.textContent = on ? "Показать" : "Скрыть";
      });
    }
  }


  let words = [];
  let checkIdx = [];
  let pos = 0;

  async function startCreate(){
    mnemonic = norm(await BIP39().generateMnemonic(256)); // 24 words
    words = mnemonic.split(" ");
    renderSeed(words);
      bindSeedActions();
checkIdx = [3, 11, 17].map(i => Math.min(i, words.length-1));
    pos = 0;
    $("cIdx").textContent = String(checkIdx[pos] + 1);
    $("confirmWord").value = "";
    $("cStatus").textContent = "";

    go("mnemonicSection");
  }

  function startConfirm(){
    $("confirmWord").value = "";
    $("cStatus").textContent = "";
    $("cIdx").textContent = String(checkIdx[pos] + 1);
    go("confirmSection");
  }

  function doConfirmNext(){
    const w = norm($("confirmWord").value);
    const idx = checkIdx[pos];
    if (w !== words[idx]) {
      status($("cStatus"), false, "Неверно. Проверь слово.");
      return;
    }
    pos++;
    if (pos >= checkIdx.length) {
      go("setPassSection");
      return;
    }
    status($("cStatus"), true, "OK");
    $("confirmWord").value = "";
    $("cIdx").textContent = String(checkIdx[pos] + 1);
  }

  async function finishCreate(){
    const p1 = $("p1").value || "";
    const p2 = $("p2").value || "";
    if (p1.length < 6) return status($("pStatus"), false, "Пароль минимум 6 символов");
    if (p1 !== p2) return status($("pStatus"), false, "Пароли не совпадают");

    status($("pStatus"), true, "Создаю…");

    const seedBuf = await BIP39().mnemonicToSeed32(mnemonic, "");
    const seedU8  = new Uint8Array(seedBuf);

    const seed32 = await sha256(seedU8);                 // 32 bytes
    const kp = nacl.sign.keyPair.fromSeed(seed32);
    const rid = makeRIDFromPub(kp.publicKey);

    const enc = await encryptSeed32(seed32, p1);

    const vault = {
      ver: 1,
      rid,
      pub: u8ToB64(kp.publicKey),
      ...enc,
      created_at: new Date().toISOString()
    };
    localStorage.setItem(LS_VAULT, JSON.stringify(vault));

    sessionStorage.setItem(SS_SEED, u8ToB64(seed32));
    setRidSession(rid);

    goWallet();
  }

  // ---------- Restore flow ----------
  async function doRestore(){
    const m = norm($("restoreMnemonic").value);
    const pass = $("restorePass").value || "";
    if (!await BIP39().validateMnemonic(m)) return status($("rStatus"), false, "Фраза некорректная (проверь слова/пробелы)");
    if (pass.length < 6) return status($("rStatus"), false, "Пароль минимум 6 символов");

    status($("rStatus"), true, "Восстанавливаю…");

    const seedBuf = await BIP39().mnemonicToSeed32(m, "");
    const seedU8  = new Uint8Array(seedBuf);
    const seed32  = await sha256(seedU8);

    const kp = nacl.sign.keyPair.fromSeed(seed32);
    const rid = makeRIDFromPub(kp.publicKey);

    const enc = await encryptSeed32(seed32, pass);
    const vault = {
      ver: 1,
      rid,
      pub: u8ToB64(kp.publicKey),
      ...enc,
      created_at: new Date().toISOString()
    };
    localStorage.setItem(LS_VAULT, JSON.stringify(vault));

    sessionStorage.setItem(SS_SEED, u8ToB64(seed32));
    setRidSession(rid);

    goWallet();
  }

  // ---------- Unlock flow ----------
  async function doUnlock(){
    let v = null;
    try { v = JSON.parse(localStorage.getItem(LS_VAULT) || "null"); } catch(_){}
    if (!v || !v.ct) return status($("uStatus"), false, "Vault не найден");
    const pass = $("unlockPass").value || "";
    if (pass.length < 6) return status($("uStatus"), false, "Пароль минимум 6 символов");

    status($("uStatus"), true, "Unlock…");
    try{
      const seed32 = await decryptSeed32(v, pass);
      sessionStorage.setItem(SS_SEED, u8ToB64(seed32));
      setRidSession(v.rid || "");
      goWallet();
    } catch(e){
      status($("uStatus"), false, "Неверный пароль или vault повреждён");
    }
  }

  // ---------- Legacy RID login ----------
  function legacyLogin(){
    const rid = ($("rid").value || "").trim();
    if (!rid) return status($("status"), false, "Введите RID");
    setRidSession(rid);
    status($("status"), true, "OK");
    goWallet();
  }

  function showSavedRid(){
    const rid = (localStorage.getItem(LS_RID2) || localStorage.getItem(LS_RID1) || localStorage.getItem(LS_LAST) || "").trim();
    if (!rid) return status($("status"), false, "RID не найден в браузере");
    $("rid").value = rid;
    status($("status"), true, "RID подставлен из браузера");
  }

  // init
  document.addEventListener("DOMContentLoaded", () => {
    // если vault есть — показываем Unlock кнопку
    try{
      const v = JSON.parse(localStorage.getItem(LS_VAULT) || "null");
      if (v && v.ct) $("btnUnlock").style.display = "";
    }catch(_){}

    $("btnCreate").onclick = startCreate;
    $("btnRestore").onclick = () => go("restoreSection");
    $("btnUnlock").onclick  = () => go("unlockSection");

    $("btnRecorded").onclick = startConfirm;
    $("btnConfirmNext").onclick = doConfirmNext;
    $("btnFinishCreate").onclick = () => finishCreate().catch(e => status($("pStatus"), false, "ERR: " + (e.message||String(e))));

    $("btnDoRestore").onclick = () => doRestore().catch(e => status($("rStatus"), false, "ERR: " + (e.message||String(e))));
    $("btnDoUnlock").onclick  = () => doUnlock().catch(e => status($("uStatus"), false, "ERR: " + (e.message||String(e))));

    $("btnBack0").onclick = () => go("step0");
    $("btnBack1").onclick = () => go("mnemonicSection");
    $("btnBack2").onclick = () => go("confirmSection");
    $("btnBackR").onclick = () => go("step0");
    $("btnBackU").onclick = () => go("step0");

    $("btnLogin").onclick = legacyLogin;
    $("btnShowRid").onclick = showSavedRid;

    // автоподстановка RID
    const rid = (localStorage.getItem(LS_RID2) || localStorage.getItem(LS_RID1) || localStorage.getItem(LS_LAST) || "").trim();
    if (rid) $("rid").value = rid;
  });
})();
