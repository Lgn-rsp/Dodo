/* LOGOS Wallet routes (same-origin). No inline scripts. */
(function(){
  // node backend
  window.API_BASE = "/api";
  // wallet proxy
  window.WALLET_API = "/wallet-api";
})();
