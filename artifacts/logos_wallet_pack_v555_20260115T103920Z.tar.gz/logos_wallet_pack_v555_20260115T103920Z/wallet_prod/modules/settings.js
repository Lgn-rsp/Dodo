/* ===== LOGOS Wallet: Settings module (v1) ===== */
(() => {
  const LS_DEV = "logos_dev_mode";

  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const $  = (sel, root=document) => root.querySelector(sel);

  function ridGet(){
    return (
      localStorage.getItem("RID") ||
      localStorage.getItem("logos_rid") ||
      sessionStorage.getItem("RID") ||
      sessionStorage.getItem("logos_rid") ||
      ""
    );
  }

  function devGet(){ return (localStorage.getItem(LS_DEV) === "1"); }
  function devSet(v){ localStorage.setItem(LS_DEV, v ? "1" : "0"); }

  function markDevOnly(){
    // 1) прячем все Details/raw блоки
    $$("details").forEach(d => {
      const t = (d.textContent || "").toLowerCase();
      const s = ($("summary", d)?.textContent || "").toLowerCase();
      if (t.includes("raw") || s.includes("details") || s.includes("raw") || t.includes("wallet-api raw")) {
        d.classList.add("devOnly");
      }
    });

    // 2) прячем pre/json дампы если есть
    $$("pre").forEach(p => {
      const t = (p.textContent || "").toLowerCase();
      if (t.includes("{") && (t.includes("rid") || t.includes("addresses") || t.includes("balances"))) {
        p.classList.add("devOnly");
      }
    });

    // 3) прячем любые элементы, где прямо написано "raw"
    $$("*").forEach(el => {
      const t = (el.textContent || "").toLowerCase();
      if (t.trim() === "details (raw)" || t.trim() === "details (wallet-api raw)" ) {
        el.classList.add("devOnly");
      }
    });
  }

  function applyDev(){
    const dev = devGet();
    document.documentElement.classList.toggle("dev", dev);

    // если у нас уже проставлены devOnly — CSS сделает остальное
    markDevOnly();

    // bridge: заменяем страшные сообщения для обычных людей
    const bridgePanel = document.getElementById("panel-bridge");
    if (bridgePanel){
      const msg = bridgePanel.querySelector(".bridgeMsg");
      if (msg){
        const txt = (msg.textContent || "");
        if (!dev && (txt.includes("HOT wallet not configured") || txt.includes('"detail"'))){
          msg.textContent = "Top up / Withdraw временно недоступны (временно).";
        }
      }
    }
  }

  function downloadJSON(filename, obj){
    const blob = new Blob([JSON.stringify(obj, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function clearWalletStorage(){
    // аккуратно удаляем только наши ключи
    const keys = [
      "RID","logos_rid","rid","logosRID",
      "logos_key","logos_priv","logos_pub",
      "wallet_key","wallet_priv","wallet_pub",
      "logos_token","logos_auth",
      "logos_wallet","logos_state",
      "LOGOS_WALLET","LOGOS_STATE",
    ];
    keys.forEach(k => { try{ localStorage.removeItem(k); }catch(e){} });
    keys.forEach(k => { try{ sessionStorage.removeItem(k); }catch(e){} });

    // удаляем всё, что начинается с logos_
    try{
      for (let i=localStorage.length-1;i>=0;i--){
        const k = localStorage.key(i);
        if (k && (k.startsWith("logos_") || k.startsWith("LOGOS_"))) localStorage.removeItem(k);
      }
    }catch(e){}
    try{
      for (let i=sessionStorage.length-1;i>=0;i--){
        const k = sessionStorage.key(i);
        if (k && (k.startsWith("logos_") || k.startsWith("LOGOS_"))) sessionStorage.removeItem(k);
      }
    }catch(e){}
  }

  function renderSettings(){
    const panel = document.getElementById("panel-settings");
    if (!panel) return;

    panel.innerHTML = `
      <div class="card">
        <div class="h">Настройки</div>
        <div class="muted">Ключи живут локально в браузере. Сервер видит только подписанные операции.</div>

        <div style="height:12px"></div>

        <div class="kvRow">
          <div>
            <div class="k">Dev mode</div>
            <div class="v muted">Скрывает/показывает технические детали (raw, debug, тексты ошибок).</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="devToggle">
            <span class="slider"></span>
          </label>
        </div>

        <div style="height:14px"></div>

        <div class="card" style="padding:14px">
          <div class="h">Локальные данные</div>
          <div class="muted">RID/ключи/состояние хранятся в localStorage.</div>

          <div style="height:10px"></div>

          <div class="btnRow">
            <button class="btn" id="btnCopyRID">Скопировать RID</button>
            <button class="btn" id="btnExport">Экспорт бэкапа</button>
            <button class="btn danger" id="btnClear">Очистить локальные данные</button>
          </div>

          <div class="muted" style="margin-top:10px" id="settingsNote"></div>
        </div>

        <div style="height:12px"></div>

        <div class="card devOnly" style="padding:14px">
          <div class="h">Dev info</div>
          <div class="muted">Только для тебя.</div>
          <div style="height:10px"></div>
          <pre id="devDump" style="white-space:pre-wrap;margin:0"></pre>
        </div>
      </div>
    `;

    const devToggle = panel.querySelector("#devToggle");
    const note = panel.querySelector("#settingsNote");
    const dump = panel.querySelector("#devDump");

    devToggle.checked = devGet();
    devToggle.addEventListener("change", () => {
      devSet(devToggle.checked);
      applyDev();
      note.textContent = devToggle.checked ? "Dev mode включён." : "Dev mode выключен (обычный режим).";
      // обновим devDump
      const rid = ridGet();
      dump.textContent = JSON.stringify({
        rid,
        origin: window.location.origin,
        api: (window.LOGOS_NODE_API || window.API_BASE || "/api"),
        wallet_api: (window.LOGOS_WALLET_API || window.WALLET_API || "/wallet-api"),
        dev_mode: devGet(),
        localStorage_keys: Object.keys(localStorage || {}).slice(0, 50)
      }, null, 2);
    });

    panel.querySelector("#btnCopyRID").addEventListener("click", async () => {
      const rid = ridGet();
      if (!rid) return (note.textContent = "RID не найден. Войди в кошелёк.");
      try{
        await navigator.clipboard.writeText(rid);
        note.textContent = "RID скопирован.";
      }catch(e){
        note.textContent = "Не удалось скопировать (браузер запретил).";
      }
    });

    panel.querySelector("#btnExport").addEventListener("click", () => {
      const rid = ridGet();
      const payload = {
        rid,
        exported_at: new Date().toISOString(),
        origin: window.location.origin,
        // сохраняем только безопасные вещи — без “сырых приватников”
        // (если приватники где-то лежат — лучше не выгружать в файл автоматически)
        hints: {
          note: "Это бэкап RID/настроек. Приватные ключи не экспортируются автоматически."
        }
      };
      const fn = `logos_wallet_backup_${Date.now()}.json`;
      downloadJSON(fn, payload);
      note.textContent = "Бэкап скачан.";
    });

    panel.querySelector("#btnClear").addEventListener("click", () => {
      const ok = confirm("Точно очистить локальные данные кошелька на этом устройстве? RID/ключи в браузере будут удалены.");
      if (!ok) return;
      clearWalletStorage();
      note.textContent = "Очищено. Перезагружаю…";
      setTimeout(() => location.reload(), 600);
    });

    // init view
    applyDev();
    note.textContent = devGet() ? "Dev mode включён." : "Dev mode выключен (обычный режим).";
    const rid = ridGet();
    dump.textContent = JSON.stringify({
      rid,
      origin: window.location.origin,
      api: (window.LOGOS_NODE_API || window.API_BASE || "/api"),
      wallet_api: (window.LOGOS_WALLET_API || window.WALLET_API || "/wallet-api"),
      dev_mode: devGet(),
    }, null, 2);

    // обновление bridge сообщений при изменениях (MutationObserver)
    const bridgePanel = document.getElementById("panel-bridge");
    if (bridgePanel){
      const obs = new MutationObserver(() => applyDev());
      obs.observe(bridgePanel, {subtree:true, childList:true, characterData:true});
    }
  }

  // старт
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", renderSettings);
  } else {
    renderSettings();
  }
})();


// PROD hard clear session password
try{sessionStorage.removeItem("PASS");sessionStorage.removeItem("logos_pass");}catch(e){}
