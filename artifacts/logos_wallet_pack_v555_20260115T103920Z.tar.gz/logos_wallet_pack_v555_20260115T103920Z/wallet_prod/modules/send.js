(function(){
  const $ = (id) => document.getElementById(id);

  function esc(s){
    return String(s ?? "")
      .replaceAll("&","&amp;")
      .replaceAll("<","&lt;")
      .replaceAll(">","&gt;")
      .replaceAll('"',"&quot;")
      .replaceAll("'","&#039;");
  }

  function readRID(){
    try{
      return (localStorage.getItem("RID") || localStorage.getItem("logos_rid") || "").trim();
    }catch(e){ return ""; }
  }

  function setStatus(msg){
    const el = $("wdStatus");
    if (el) el.textContent = msg || "";
  }

  function setRaw(obj){
    const pre = $("wdRaw");
    if (!pre) return;
    try{ pre.textContent = JSON.stringify(obj, null, 2); }
    catch(e){ pre.textContent = String(obj); }
  }

  function fillNetworkOptionsFromBalances(balJson){
    const sel = $("wdNetwork");
    if (!sel) return;

    const b = (balJson && balJson.balances) ? balJson.balances : {};
    const opts = [];

    // Withdraw у нас "USDT". Реальные сети вывода: ERC20 (ETH) и TRC20 (TRON)
    if (b.ETH)  opts.push({v:"ETH",  t:"ETH (ERC20)"});
    if (b.TRON) opts.push({v:"TRON", t:"TRON (TRC20)"});

    // fallback если вдруг API не дал balances
    if (opts.length === 0) opts.push({v:"ETH", t:"ETH (ERC20)"});

    const cur = sel.value;
    sel.innerHTML = "";
    for (const o of opts){
      const opt = document.createElement("option");
      opt.value = o.v;
      opt.textContent = o.t;
      sel.appendChild(opt);
    }
    if (cur && [...sel.options].some(x => x.value === cur)) sel.value = cur;
  }

  async function refreshNetworks(){
    try{
      const rid = readRID();
      if (!rid) return;

      const base = window.WALLET_API || "/wallet-api";
      const r = await fetch(base + "/v1/balances/" + encodeURIComponent(rid), { cache: "no-store" });
      if (!r.ok) return;
      const j = await r.json();
      fillNetworkOptionsFromBalances(j);
    }catch(e){}
  }

  function clearForm(){
    if ($("wdAmount")) $("wdAmount").value = "";
    if ($("wdTo")) $("wdTo").value = "";
    setStatus("");
    setRaw("");
  }

  async function doWithdraw(){
    const rid = readRID();
    if (!rid) return setStatus("ERR: RID не найден. Зайди через /wallet/auth.html");

    const base = window.WALLET_API || "/wallet-api";

    const net = ($("wdNetwork") && $("wdNetwork").value) ? $("wdNetwork").value : "ETH";
    const amountStr = String(($("wdAmount") && $("wdAmount").value) || "").trim();
    const to = String(($("wdTo") && $("wdTo").value) || "").trim();

    if (!amountStr) return setStatus("ERR: введи Amount (целое число).");
    if (!/^\d+$/.test(amountStr)) return setStatus("ERR: Amount должен быть целым числом (integer).");
    const amount = Number(amountStr);
    if (!Number.isFinite(amount) || amount <= 0) return setStatus("ERR: Amount должен быть > 0.");

    if (!to || to.length < 8) return setStatus("ERR: введи адрес получателя.");

    setStatus("request…");
    setRaw("");

    try{
      const body = { rid, network: net, amount, to };

      const r = await fetch(base + "/v1/withdraw", {
        method: "POST",
        headers: { "content-type":"application/json" },
        body: JSON.stringify(body),
        cache: "no-store"
      });

      const j = await r.json().catch(()=>({}));
      setRaw(j);

      if (!r.ok){
        return setStatus("ERR: HTTP " + r.status + " — " + (j && (j.error || j.message) ? (j.error || j.message) : "withdraw failed"));
      }

      setStatus("OK: отправлено (" + esc(net) + ").");
    }catch(e){
      setStatus("ERR: " + (e && e.message ? e.message : String(e)));
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    refreshNetworks();

    const btnSend = $("btnWithdraw");
    const btnClear = $("btnWithdrawClear");

    if (btnSend) btnSend.addEventListener("click", doWithdraw);
    if (btnClear) btnClear.addEventListener("click", clearForm);

    // enter = send (в поле адреса)
    const to = $("wdTo");
    if (to){
      to.addEventListener("keydown", (e) => {
        if (e.key === "Enter") doWithdraw();
      });
    }
  });
})();
