/* LGN send via /node-api/submit_tx
   Uses sessionStorage logos_sk_seed_b64 (seed32) + tweetnacl ed25519
*/
(() => {
  const NODE_API = `${location.origin}/node-api`;
  const SS_SEED = "logos_sk_seed_b64";

  const byId = (id)=>document.getElementById(id);
  const pick = (...ids)=>ids.map(byId).find(Boolean);

  function setStatus(ok, msg){
    const el = pick("lgnStatus","sendStatus","statusLGN");
    if (el){ el.textContent = msg||""; el.className = ok ? "status ok" : "status err"; }
  }

  function b64ToU8(b64){
    const s = atob(b64);
    const u8 = new Uint8Array(s.length);
    for(let i=0;i<s.length;i++) u8[i]=s.charCodeAt(i);
    return u8;
  }

  function u8tohex(u8){
    return Array.from(u8).map(b=>b.toString(16).padStart(2,"0")).join("");
  }

  function readRID(){
    return (localStorage.getItem("logos_rid") || localStorage.getItem("RID") || "").trim();
  }

  function readToRid(){
    // В твоём UI это именно lgmTo
    const el = pick("lgmTo","lgnTo","toRid","to");
    return (el?.value || "").trim();
  }

  function parseAmountMicro(){
    const el = pick("lgmAmount","lgnAmount","amountLGN","amount");
    const s0 = (el?.value || "").trim().replace(",",".");
    if (!s0) throw new Error("Введите Amount");
    if (!/^\d+(\.\d+)?$/.test(s0)) throw new Error("Некорректный Amount");
    const [a,b=""] = s0.split(".");
    const frac = (b+"000000").slice(0,6);
    const micro = BigInt(a)*1000000n + BigInt(frac);
    if (micro<=0n) throw new Error("Amount должен быть > 0");
    return micro;
  }

  async function getJSON(url){
    const r = await fetch(url,{cache:"no-store",credentials:"omit"});
    const t = await r.text();
    if (!r.ok) throw new Error(`${r.status} ${t}`.slice(0,300));
    try { return JSON.parse(t); } catch { return t; }
  }

  async function postJSON(url, body){
    const r = await fetch(url,{
      method:"POST",
      headers:{"content-type":"application/json"},
      body: JSON.stringify(body),
      cache:"no-store",
      credentials:"omit"
    });
    const t = await r.text();
    if (!r.ok) throw new Error(`${r.status} ${t}`.slice(0,600));
    try { return JSON.parse(t); } catch { return t; }
  }

  async function getNextNonce(rid){
    const j = await getJSON(`${NODE_API}/balance/${encodeURIComponent(rid)}`);
    const raw = (j && typeof j==="object" && (j.next_nonce ?? j.nonce ?? j.seq ?? j.sequence));
    if (raw===undefined || raw===null) throw new Error("В /balance нет nonce/next_nonce");
    const bn = BigInt(raw);
    // если отдаёте next_nonce — берём как есть, если nonce — добавим 1
    if (j && typeof j==="object" && j.next_nonce !== undefined) return bn;
    return bn + 1n;
  }

  function canonicalBytes(tx){
    const o = {from:tx.from,to:tx.to,amount:tx.amount,nonce:tx.nonce,memo:tx.memo??null};
    return new TextEncoder().encode(JSON.stringify(o));
  }

  async function sendLGN(){
    try{
      const from = readRID();
      if (!from) throw new Error("Нет RID. Сначала Create/Restore/Unlock или Legacy login.");
      const to = readToRid();
      if (!to) throw new Error("Введите RID получателя.");

      const seedB64 = sessionStorage.getItem(SS_SEED);
      if (!seedB64) throw new Error("Ключ не разблокирован. Вернись на старт и сделай Unlock.");
      if (!window.nacl) throw new Error("tweetnacl не загружен (проверь app.html).");

      const seed32 = b64ToU8(seedB64);
      const kp = nacl.sign.keyPair.fromSeed(seed32);

      const amount = parseAmountMicro();
      const nonce = await getNextNonce(from);

      const tx = { from, to, amount: amount.toString(), nonce: nonce.toString(), memo: null };
      const msg = canonicalBytes(tx);
      const sig = nacl.sign.detached(new Uint8Array(msg), kp.secretKey);

      const body = { ...tx, sig_hex: u8tohex(sig) };
      setStatus(true, "sending…");
      const res = await postJSON(`${NODE_API}/submit_tx`, body);
      setStatus(true, "OK: tx submitted");
      console.log("[lgn_send] submit result:", res);
    }catch(e){
      setStatus(false, "ERR: " + (e.message||String(e)));
      console.warn(e);
    }
  }

  function bind(){
    // найдём кнопку “Send LGN”
    const btn = [...document.querySelectorAll("button")].find(b => /send\s*lgn/i.test(b.textContent||""));
    if (!btn) { console.warn("[lgn_send] button not found"); return; }
    btn.addEventListener("click", (ev)=>{ ev.preventDefault(); sendLGN(); }, true);
    console.log("[lgn_send] ready (seed vault mode)");
  }

  if (document.readyState==="loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})();
