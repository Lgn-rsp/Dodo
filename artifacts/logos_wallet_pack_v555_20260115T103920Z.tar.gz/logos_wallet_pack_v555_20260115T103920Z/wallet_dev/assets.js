(() => {
  const $ = (q, el=document) => el.querySelector(q);

  function getRID(){
    return (localStorage.getItem("logos_rid") || "").trim();
  }

  async function jget(url){
    const r = await fetch(url, { cache: "no-store" });
    const t = await r.text();
    let data = {};
    try{ data = t ? JSON.parse(t) : {}; }catch(_){ data = { raw: t }; }
    if(!r.ok) throw new Error(`${r.status} ${url}: ${t.slice(0,200)}`);
    return data;
  }

  function fmtNum(x){
    if(x === null || x === undefined) return "0";
    const s = String(x);
    return s;
  }

  async function detectNodeBase(){
    // node-api у тебя работает и так, но делаем безопасно
    const cands = ["/node-api", "/node-api/api"];
    for(const b of cands){
      try{
        await jget(`${b}/healthz`);
        return b;
      }catch(_){}
    }
    return "/node-api";
  }

  function toast(msg){
    try{
      let t = $("#_toast");
      if(!t){
        t = document.createElement("div");
        t.id = "_toast";
        t.style.cssText = "position:fixed;left:50%;bottom:110px;transform:translateX(-50%);padding:10px 14px;border-radius:12px;z-index:9999;background:rgba(20,20,30,.75);border:1px solid rgba(255,255,255,.14);color:rgba(255,255,255,.92);backdrop-filter: blur(14px);box-shadow:0 20px 60px rgba(0,0,0,.5);font: 14px system-ui;opacity:0;transition:opacity .18s ease;";
        document.body.appendChild(t);
      }
      t.textContent = msg;
      t.style.opacity = "1";
      clearTimeout(t._tm);
      t._tm = setTimeout(()=>{ t.style.opacity="0"; }, 1400);
    }catch(_){}
  }

  async function copyText(txt){
    try{
      await navigator.clipboard.writeText(txt);
      toast("Скопировано");
    }catch(_){
      // fallback
      const ta = document.createElement("textarea");
      ta.value = txt;
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      toast("Скопировано");
    }
  }

  function findAssetsHost(){
    // пробуем самые вероятные варианты (разная разметка)
    return (
      document.querySelector('[data-page="assets"]') ||
      document.getElementById("page-assets") ||
      document.getElementById("assetsPage") ||
      document.querySelector(".page.assets") ||
      document.querySelector(".assetsPage") ||
      document.querySelector('[data-tab="assets"]') ||
      null
    );
  }

  function ensureUI(host){
    let wrap = host.querySelector("#assetsWrap");
    if(!wrap){
      wrap = document.createElement("div");
      wrap.id = "assetsWrap";
      wrap.className = "assetsWrap";
      host.prepend(wrap);
    }

    wrap.innerHTML = `
      <div class="assetsHead">
        <div>
          <div class="assetsTitle">Активы</div>
          <div class="assetsSub">Баланс + адреса для депозита (BTC / ETH / TRON / USDT)</div>
        </div>
        <button class="btn btn--soft" id="assetsRefresh" type="button">Обновить</button>
      </div>

      <div class="assetsGrid" id="assetsGrid">
        <div class="assetCard"><div class="muted">Загрузка...</div></div>
      </div>
    `;
    return wrap;
  }

  function cardHTML({sym, name, bal, addr, note}){
    const addrShort = addr ? (addr.slice(0, 8) + "…" + addr.slice(-6)) : "—";
    return `
      <div class="assetCard">
        <div class="assetTop">
          <div class="assetSym">${sym}</div>
          <div class="assetMeta">
            <div class="assetName">${name}</div>
            <div class="assetBal">${bal}</div>
          </div>
        </div>

        <div class="assetAddrRow">
          <div class="assetAddr mono" title="${addr || ""}">${addrShort}</div>
          <button class="chip chip--small" type="button" data-copy="${addr || ""}">Copy</button>
        </div>

        ${note ? `<div class="assetNote muted">${note}</div>` : ``}
      </div>
    `;
  }

  async function loadAndRender(){
    const host = findAssetsHost();
    if(!host) return; // если активы-страницы нет, не мешаем UI

    const wrap = ensureUI(host);
    const grid = wrap.querySelector("#assetsGrid");
    const rid = getRID();

    if(!rid){
      grid.innerHTML = `<div class="assetCard"><div class="muted">RID не найден. Сначала создай/восстанови кошелёк.</div></div>`;
      return;
    }

    try{
      const nodeBase = await detectNodeBase();

      // 1) LGN balance (node-api)
      const lgn = await jget(`${nodeBase}/balance/${encodeURIComponent(rid)}`);

      // 2) мульти-активы + адреса (wallet-api)
      const b = await jget(`/wallet-api/v1/balances/${encodeURIComponent(rid)}`);

      const addr = (b && b.addresses) ? b.addresses : {};
      const bal  = (b && b.balances)  ? b.balances  : {};

      const cards = [];

      cards.push(cardHTML({
        sym: "LGN",
        name: "LOGOS",
        bal: fmtNum(lgn?.balance ?? 0),
        addr: rid,
        note: "Внутрисетевой RID (LGN)"
      }));

      cards.push(cardHTML({
        sym: "BTC",
        name: "Bitcoin",
        bal: fmtNum(bal?.BTC?.total_btc ?? "0"),
        addr: addr?.BTC || "",
        note: bal?.BTC?.source ? `Источник: ${bal.BTC.source}` : ""
      }));

      cards.push(cardHTML({
        sym: "ETH",
        name: "Ethereum",
        bal: fmtNum(bal?.ETH?.eth ?? "0"),
        addr: addr?.ETH || "",
        note: bal?.ETH?.source ? `Источник: ${bal.ETH.source}` : ""
      }));

      cards.push(cardHTML({
        sym: "TRX",
        name: "TRON",
        bal: fmtNum(bal?.TRON?.trx ?? "0"),
        addr: addr?.TRON || "",
        note: bal?.TRON?.source ? `Источник: ${bal.TRON.source}` : ""
      }));

      cards.push(cardHTML({
        sym: "USDT",
        name: "Tether (ERC20)",
        bal: fmtNum(bal?.ETH?.usdt_erc20?.usdt ?? "0"),
        addr: addr?.USDT_ERC20 || addr?.ETH || "",
        note: bal?.ETH?.usdt_erc20?.contract ? `Contract: ${bal.ETH.usdt_erc20.contract}` : ""
      }));

      cards.push(cardHTML({
        sym: "USDT",
        name: "Tether (TRC20)",
        bal: fmtNum(bal?.TRON?.usdt_trc20?.usdt ?? "0"),
        addr: addr?.USDT_TRC20 || addr?.TRON || "",
        note: bal?.TRON?.usdt_trc20?.contract ? `Contract: ${bal.TRON.usdt_trc20.contract}` : ""
      }));

      grid.innerHTML = cards.join("\n");

      // copy handlers
      grid.querySelectorAll("[data-copy]").forEach(btn => {
        btn.addEventListener("click", () => {
          const v = btn.getAttribute("data-copy") || "";
          if(!v) return toast("Адрес пустой");
          copyText(v);
        });
      });

    }catch(e){
      grid.innerHTML = `<div class="assetCard"><div class="muted">Ошибка загрузки: ${String(e).slice(0,200)}</div></div>`;
    }
  }

  function hook(){
    const host = findAssetsHost();
    if(!host) return;

    // кнопка обновить
    const r = document.getElementById("assetsRefresh");
    if(r && !r._wired){
      r._wired = true;
      r.addEventListener("click", loadAndRender);
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    // первая отрисовка + подстраховка
    loadAndRender();
    setTimeout(() => { hook(); loadAndRender(); }, 350);
  });

  // если вкладки переключаются через hidden/class — при переключении подхватим
  document.addEventListener("click", (ev) => {
    const t = ev.target;
    if(!(t instanceof HTMLElement)) return;
    const nav = t.closest('[data-nav="assets"],[data-tab="assets"]');
    if(nav){
      setTimeout(loadAndRender, 120);
    }
  });
})();
