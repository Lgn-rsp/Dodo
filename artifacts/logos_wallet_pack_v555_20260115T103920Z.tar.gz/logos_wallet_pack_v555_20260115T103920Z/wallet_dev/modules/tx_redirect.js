/* tx_redirect.js — redirect old /transfer -> /submit_tx and normalize body to TxIn */
(() => {
  const _fetch = window.fetch.bind(window);

  function isHex(s){
    s = String(s||"").replace(/^0x/,"").trim();
    return s.length > 0 && s.length % 2 === 0 && /^[0-9a-fA-F]+$/.test(s);
  }

  function b64urlToBytes(b64url){
    try{
      let s = String(b64url||"").replace(/-/g,'+').replace(/_/g,'/');
      while (s.length % 4) s += '=';
      const bin = atob(s);
      const u = new Uint8Array(bin.length);
      for (let i=0;i<bin.length;i++) u[i] = bin.charCodeAt(i);
      return u;
    }catch(e){ return null; }
  }

  function bytesToHex(u){
    let out = "";
    for (let i=0;i<u.length;i++) out += u[i].toString(16).padStart(2,"0");
    return out;
  }

  function normalizeTx(body){
    const j = body && typeof body === "object" ? body : {};
    const from = j.from || j.rid_from || j.sender || j.rid || "";
    const to   = j.to   || j.rid_to   || j.receiver || "";
    let amount = j.amount_mic ?? j.amount_micro ?? j.amount ?? 0;
    const nonce = j.nonce ?? j.n ?? j.account_nonce;

    // если вдруг прислали amount_lgn — переводим в micro-LGN
    if (j.amount_lgn !== undefined && j.amount_lgn !== null){
      const a = Number(j.amount_lgn);
      if (isFinite(a)) amount = Math.round(a * 1e6);
    }

    // подпись: sig_hex обязательно
    let sig_hex = j.sig_hex || j.sigHex || "";
    if (!sig_hex){
      const s = j.sig || j.signature || j.sig_b64 || j.sigB64 || "";
      if (s){
        if (isHex(s)) sig_hex = String(s).replace(/^0x/,"");
        else {
          const u = b64urlToBytes(s);
          if (u) sig_hex = bytesToHex(u);
        }
      }
    }

    const memo = (j.memo === undefined ? null : j.memo);

    return { from, to, amount, nonce, memo, sig_hex };
  }

  window.fetch = async (input, init={}) => {
    try{
      const url = (typeof input === "string") ? input : (input && input.url ? input.url : "");
      if (url.includes("/transfer")){
        const newUrl = url.replace("/transfer", "/submit_tx");

        let bodyObj = {};
        try{ bodyObj = JSON.parse(init.body || "{}"); }catch(e){ bodyObj = {}; }

        const tx = normalizeTx(bodyObj);

        const newInit = {
          ...init,
          method: "POST",
          headers: { ...(init.headers||{}), "Content-Type":"application/json" },
          body: JSON.stringify({
            from: tx.from,
            to: tx.to,
            amount: tx.amount,
            nonce: tx.nonce,
            memo: tx.memo,
            sig_hex: tx.sig_hex
          })
        };

        return _fetch(newUrl, newInit);
      }
    }catch(e){}
    return _fetch(input, init);
  };

  console.log("[tx_redirect] installed: /transfer -> /submit_tx");
})();
