/* modules/send.js — REAL SEND LGN (TxIn -> /api/submit_tx) */
(() => {
  function $(sel, root=document){ return root.querySelector(sel); }

  function ridGet(){
    return localStorage.getItem("RID")
      || localStorage.getItem("logos_rid")
      || localStorage.getItem("logos_last_rid")
      || sessionStorage.getItem("RID")
      || sessionStorage.getItem("logos_rid")
      || "";
  }

  function nodeApi(){
    return (window.LOGOS_NODE_API || "/api").replace(/\/+$/,"");
  }

  function setMsg(panel, text, ok=true){
    const el = $("#sendMsg", panel) || $(".sendMsg", panel);
    if (!el) return;
    el.textContent = text || "";
    el.style.opacity = text ? "1" : "0";
    el.style.color = ok ? "" : "#ff6b6b";
  }

  function b64ToU8(b64){
    b64 = (b64||"").replace(/-/g,'+').replace(/_/g,'/');
    while (b64.length % 4) b64 += "=";
    const s = atob(b64);
    const u = new Uint8Array(s.length);
    for (let i=0;i<s.length;i++) u[i] = s.charCodeAt(i);
    return u;
  }

  function hex(u8){
    let out = "";
    for (let i=0;i<u8.length;i++) out += u8[i].toString(16).padStart(2,"0");
    return out;
  }

  // точное преобразование LGN -> micro-LGN (6 decimals)
  function lgnToMicro(s){
    s = String(s||"").trim().replace(",",".");
    if (!s) return null;
    const m = s.match(/^(\d+)(?:\.(\d{0,6})\d*)?$/);
    if (!m) return null;
    const a = m[1];
    const frac = (m[2]||"").padEnd(6,"0");
    const microStr = a + frac;
    // без BigInt не рискуем переполнением? у нас u64 — используем BigInt
    return BigInt(microStr);
  }

  async function getJSON(url){
    const r = await fetch(url, {method:"GET"});
    const t = await r.text();
    let j=null; try{ j=JSON.parse(t);}catch(_){}
    if (!r.ok){
      const msg = j?.detail || j?.error || j?.message || t;
      throw new Error("HTTP " + r.status + ": " + msg);
    }
    return j ?? t;
  }

  async function postJSON(url, body){
    const r = await fetch(url, {
      method:"POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body || {})
    });
    const t = await r.text();
    let j=null; try{ j=JSON.parse(t);}catch(_){}
    if (!r.ok){
      const msg = j?.detail || j?.error || j?.message || t;
      throw new Error("HTTP " + r.status + ": " + msg);
    }
    return j ?? t;
  }

  // Пытаемся найти приватный ключ в localStorage (PKCS8 base64/base64url) — без знания имени.
  async function findEd25519PrivKeyForRid(rid){
    const keys = [];
    for (let i=0;i<localStorage.length;i++){
      const k = localStorage.key(i);
      const v = localStorage.getItem(k);
      if (!v) continue;
      if (v.length < 40) continue;
      keys.push([k,v]);
    }

    for (const [k,v] of keys){
      // пропускаем явно не ключи
      if (k.toLowerCase().includes("theme")) continue;
      if (k.toLowerCase().includes("lang")) continue;

      // пробуем как pkcs8 base64/base64url
      let u8 = null;
      try { u8 = b64ToU8(v); } catch(_){}
      if (!u8 || u8.length < 40) continue;

      try{
        const priv = await crypto.subtle.importKey(
          "pkcs8",
          u8,
          { name:"Ed25519" },
          false,
          ["sign"]
        );

        // проверяем: подпись должна валидироваться на pubkey, который соответствует RID
        // (RID у тебя base58(pubkey) — но мы не будем вычислять pubkey: просто вернём ключ и надеемся что он правильный;
        // если неправильный — сервер вернёт bad_signature)
        return priv;
      }catch(_){
        // not a pkcs8 ed25519
      }
    }
    return null;
  }

  function canonBytes(tx){
    // ВАЖНО: это канонизация “по-человечески”.
    // Если на ноде другой формат — сразу увидим "bad_signature", и тогда сделаем canon-endpoint.
    const memo = tx.memo ? String(tx.memo) : "";
    const s = `${tx.from}|${tx.to}|${tx.amount}|${tx.nonce}|${memo}`;
    return new TextEncoder().encode(s);
  }

  async function signTx(privKey, tx){
    const msg = canonBytes(tx);
    const sig = await crypto.subtle.sign({name:"Ed25519"}, privKey, msg);
    return hex(new Uint8Array(sig));
  }

  function render(){
    const panel =
      document.getElementById("panel-send")
      || document.getElementById("panel-transfer")
      || document.querySelector('[data-panel="send"]')
      || document.querySelector('#panel-send');

    if (!panel) return;

    const btnSend = $("#btnSendLGN", panel) || $("#sendBtn", panel) || panel.querySelector("button");
    if (!btnSend) return;

    btnSend.addEventListener("click", async () => {
      try{
        const from = ridGet();
        const to = ($("#sendToRid", panel)?.value || "").trim();
        const amountStr = ($("#sendAmount", panel)?.value || "").trim();
        const memo = ($("#sendMemo", panel)?.value || "").trim();

        if (!from) return setMsg(panel, "RID не найден. Перезайди в кошелёк.", false);
        if (!to || to.length < 12) return setMsg(panel, "Введи правильный RID получателя.", false);

        const micro = lgnToMicro(amountStr);
        if (micro === null) return setMsg(panel, "Введи сумму (например 1 или 0.5).", false);
        if (micro <= 0n) return setMsg(panel, "Сумма должна быть больше 0.", false);

        setMsg(panel, "Получаю nonce…", true);
        const bal = await getJSON(nodeApi() + "/balance/" + encodeURIComponent(from));
        const nonceNow = (bal && (bal.nonce ?? bal.nonce_u64 ?? bal.account_nonce)) ;
        if (nonceNow === undefined || nonceNow === null) {
          return setMsg(panel, "Не смог прочитать nonce из /balance. Нужно уточнить формат ответа.", false);
        }
        const nonce = BigInt(nonceNow) + 1n;

        setMsg(panel, "Ищу ключ…", true);
        const priv = await findEd25519PrivKeyForRid(from);
        if (!priv){
          return setMsg(panel, "Нет приватного ключа в браузере. Нужен импорт/создание ключа (добавим в Настройки).", false);
        }

        const tx = {
          from,
          to,
          amount: micro.toString(),
          nonce: nonce.toString(),
          memo: memo || null
        };

        setMsg(panel, "Подписываю…", true);
        const sig_hex = await signTx(priv, tx);

        setMsg(panel, "Отправляю в сеть…", true);
        const res = await postJSON(nodeApi() + "/submit_tx", {
          from: tx.from,
          to: tx.to,
          amount: Number(tx.amount), // u64 — у тебя тут маленькие суммы; если будут огромные — переведём на строку на сервере
          nonce: Number(tx.nonce),
          memo: tx.memo,
          sig_hex
        });

        setMsg(panel, "✅ Отправлено. " + (res?.txid ? ("txid: " + res.txid) : (res?.info ? res.info : "")), true);
      }catch(e){
        setMsg(panel, "ERR: " + (e?.message || e), false);
      }
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", render);
  else render();
})();
