'use strict';

const DB_NAME = 'logos_wallet_v2';
const STORE   = 'keys';
const enc = new TextEncoder();

const ED25519_PKCS8_PREFIX = new Uint8Array([
  0x30,0x2e,0x02,0x01,0x00,
  0x30,0x05,0x06,0x03,0x2b,0x65,0x70,
  0x04,0x22,0x04,0x20
]);

const $ = (id) => document.getElementById(id);

function setStatus(t){
  const el = $('status');
  if (el) el.textContent = 'Статус: ' + t;
}

function ensureEnv(){
  if (!window.isSecureContext) throw new Error('Нужен HTTPS (secure context)');
  if (!window.crypto?.subtle) throw new Error('WebCrypto недоступен');
  if (!window.indexedDB) throw new Error('IndexedDB недоступен');
  if (!window.nacl?.sign?.keyPair?.fromSeed) throw new Error('tweetnacl не загружен (нет window.nacl)');
}

const B58_ALPH = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58encode(bytes){
  const b = (bytes instanceof Uint8Array) ? bytes : new Uint8Array(bytes||[]);
  if (b.length === 0) return "";
  let digits = [0];
  for (let i=0;i<b.length;i++){
    let carry = b[i];
    for (let j=0;j<digits.length;j++){
      const x = digits[j]*256 + carry;
      digits[j] = x % 58;
      carry = (x/58) | 0;
    }
    while (carry){
      digits.push(carry % 58);
      carry = (carry/58) | 0;
    }
  }
  let out = "";
  for (let k=0;k<b.length && b[k]===0;k++) out += "1";
  for (let q=digits.length-1;q>=0;q--) out += B58_ALPH[digits[q]];
  return out;
}

async function sha256(u8){
  const d = await crypto.subtle.digest('SHA-256', u8);
  return new Uint8Array(d);
}

function pkcs8FromSeed(seed32){
  const seed = (seed32 instanceof Uint8Array) ? seed32 : new Uint8Array(seed32||[]);
  if (seed.length !== 32) throw new Error('seed must be 32 bytes');
  const out = new Uint8Array(ED25519_PKCS8_PREFIX.length + 32);
  out.set(ED25519_PKCS8_PREFIX, 0);
  out.set(seed, ED25519_PKCS8_PREFIX.length);
  return out;
}

async function deriveKey(pass, saltU8, usage=['encrypt','decrypt']){
  const keyMat = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name:'PBKDF2', salt: saltU8, iterations:120000, hash:'SHA-256' },
    keyMat,
    { name:'AES-GCM', length:256 },
    false,
    usage
  );
}

async function aesEncrypt(aesKey, plainU8){
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, aesKey, plainU8);
  return { iv, ct: new Uint8Array(ct) };
}

async function aesDecrypt(aesKey, ivU8, ctU8){
  const plain = await crypto.subtle.decrypt({ name:'AES-GCM', iv: ivU8 }, aesKey, ctU8);
  return new Uint8Array(plain);
}

let DBP = null;
function openDb(){
  if (DBP) return DBP;
  DBP = new Promise((resolve,reject)=>{
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return DBP;
}

async function idbGet(key){
  const db = await openDb();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(STORE,'readonly');
    const st = tx.objectStore(STORE);
    const r = st.get(key);
    r.onsuccess = ()=>resolve(r.result || null);
    r.onerror = ()=>reject(r.error);
  });
}

async function idbPut(key, val){
  const db = await openDb();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(STORE,'readwrite');
    const st = tx.objectStore(STORE);
    const r = st.put(val, key);
    r.onsuccess = ()=>resolve(true);
    r.onerror = ()=>reject(r.error);
  });
}

async function idbListRids(){
  const db = await openDb();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(STORE,'readonly');
    const st = tx.objectStore(STORE);
    const out = [];
    const req = st.openCursor();
    req.onsuccess = () => {
      const cur = req.result;
      if (!cur) return resolve(out);
      const k = String(cur.key||'');
      if (k.startsWith('acct:')) out.push(k.slice(5));
      cur.continue();
    };
    req.onerror = ()=>reject(req.error);
  });
}

function setSession(rid, pass){
  // mirror to localStorage for app.js compatibility
  try {
    localStorage.setItem("logos_rid", String(rid||""));
    localStorage.setItem("RID", String(rid||""));
    if (pass != null) localStorage.setItem("logos_pass", String(pass||""));
  } catch(e) {}

  sessionStorage.setItem('logos_rid', rid);
  sessionStorage.setItem('logos_pass', pass);
  localStorage.setItem('logos_rid', rid);
  localStorage.setItem('logos_pass', pass);
}

function validatePass(p){
  const s = String(p||'').trim();
  if (s.length < 10) throw new Error('Пароль слишком короткий (мин 10)');
  return s;
}

function normalizePhrase(ph){
  return String(ph||'').trim().replace(/\s+/g,' ').toLowerCase();
}

const WORDS = [
  "alpha","bravo","canyon","delta","eagle","frost","galaxy","harbor","ivory","jungle","karma","legend",
  "matrix","nebula","orbit","pioneer","quantum","raven","signal","temple","union","vector","wander","xenon",
  "yellow","zenith","acoustic","breeze","crystal","drift","ember","forest","glimmer","horizon","island","jewel",
  "kernel","lunar","mirror","nova","oasis","prism","quiet","river","stone","thunder","ultra","vivid","whisper","zero"
];

function genPhrase16(){
  const rnd = crypto.getRandomValues(new Uint8Array(16));
  const w = [];
  for (let i=0;i<16;i++) w.push(WORDS[rnd[i] % WORDS.length]);
  return w.join(' ');
}

async function seedFromPhrase(phrase){
  const p = normalizePhrase(phrase);
  if (!p) throw new Error('Фраза пустая');
  const h = await sha256(enc.encode(p));
  return h.slice(0,32);
}

function ridFromSeed(seed32){
  const kp = nacl.sign.keyPair.fromSeed(seed32);
  const pub = new Uint8Array(kp.publicKey);
  return base58encode(pub);
}

async function storeAccount(rid, pass, seed32){
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const aes = await deriveKey(pass, salt, ['encrypt','decrypt']);
  const pkcs8 = pkcs8FromSeed(seed32);
  const {iv, ct} = await aesEncrypt(aes, pkcs8);

  const meta = { salt: Array.from(salt), iv: Array.from(iv), priv: Array.from(ct), ts: Date.now() };
  await idbPut('acct:' + rid, meta);
}

async function loadAndVerify(rid, pass){
  const meta = await idbGet('acct:' + rid);
  if (!meta) throw new Error('RID не найден на этом устройстве (нет локальной записи)');
  const salt = new Uint8Array(meta.salt || []);
  const iv   = new Uint8Array(meta.iv || []);
  const ct   = new Uint8Array(meta.priv || []);
  const aes  = await deriveKey(pass, salt, ['decrypt']);
  const pkcs8 = await aesDecrypt(aes, iv, ct);
  const seed = pkcs8.slice(ED25519_PKCS8_PREFIX.length);
  const checkRid = ridFromSeed(seed);
  if (checkRid !== rid) throw new Error('Неверный пароль');
  return true;
}

async function doShow(){
  try{
    ensureEnv();
    const list = await idbListRids();
    const box = $('savedList');
    if (box){
      box.style.display = '';
      box.textContent = list.length ? list.map(x=>'• '+x).join('\n') : '— пусто —';
    }
    setStatus('saved RID: ' + list.length);
  }catch(e){
    setStatus('ERR: ' + (e?.message || String(e)));
  }
}

async function doLogin(){
  try{
    ensureEnv();
    const rid = String($('ridIn')?.value||'').trim();
    const pass = validatePass($('passIn')?.value||'');
    if (!rid) throw new Error('RID пустой');
    setStatus('checking…');
    await loadAndVerify(rid, pass);
    setSession(rid, pass);
    setStatus('ok → opening wallet…');
    location.href = './app.html';
  }catch(e){
    setStatus('ERR: ' + (e?.message || String(e)));
  }
}

async function doCreate(){
  try{
    ensureEnv();
    const pass = validatePass($('newPass')?.value||'');
    const phrase = genPhrase16();
    const seed = await seedFromPhrase(phrase);
    const rid = ridFromSeed(seed);
    await storeAccount(rid, pass, seed);
    const out = $('newPhraseOut');
    if (out) out.value = phrase;
    setSession(rid, pass);
    setStatus('created: ' + rid + ' → opening wallet…');
    location.href = './app.html';
  }catch(e){
    setStatus('ERR: ' + (e?.message || String(e)));
  }
}

async function doRestore(){
  try{
    ensureEnv();
    const phrase = normalizePhrase($('phraseIn')?.value||'');
    const pass = validatePass($('restorePass')?.value||'');
    if (!phrase) throw new Error('Фраза пустая');
    const seed = await seedFromPhrase(phrase);
    const rid = ridFromSeed(seed);
    await storeAccount(rid, pass, seed);
    setSession(rid, pass);
    setStatus('restored: ' + rid + ' → opening wallet…');
    location.href = './app.html';
  }catch(e){
    setStatus('ERR: ' + (e?.message || String(e)));
  }
}

window.addEventListener('DOMContentLoaded', ()=>{
  $('btnShow')?.addEventListener('click', doShow);
  $('btnLogin')?.addEventListener('click', doLogin);
  $('btnCreate')?.addEventListener('click', doCreate);
  $('btnRestore')?.addEventListener('click', doRestore);
  setStatus('ready');
});
