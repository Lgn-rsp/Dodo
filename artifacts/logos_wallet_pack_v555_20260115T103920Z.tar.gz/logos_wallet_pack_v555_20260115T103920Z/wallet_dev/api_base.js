(() => {
  // same-origin only
  window.API_BASE   = "/api";        // node backend (nginx -> 127.0.0.1:8080)
  window.WALLET_API = "/wallet-api"; // wallet proxy (FastAPI)
})();
