'use strict';

(function () {
  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

  function activate(name){
    const tabs  = qsa('.tab[data-tab]');
    const cards = qsa('.tabCard[data-tab]');

    tabs.forEach(b => b.classList.toggle('is-active', b.getAttribute('data-tab') === name));
    cards.forEach(c => c.classList.toggle('is-active', c.getAttribute('data-tab') === name));

    // optional: hash для прямой ссылки
    try { history.replaceState(null, '', '#'+name); } catch {}
    // вверх, чтобы не казалось что "всё в одной вкладке"
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  window.LOGOS_TABS = { activate };

  window.addEventListener('DOMContentLoaded', () => {
    const tabs = qsa('.tab[data-tab]');
    if (!tabs.length) return;

    tabs.forEach(btn => {
      btn.addEventListener('click', () => activate(btn.getAttribute('data-tab')));
    });

    const fromHash = (location.hash || '').replace('#','').trim();
    const initial = fromHash && tabs.some(t => t.getAttribute('data-tab') === fromHash)
      ? fromHash
      : tabs[0].getAttribute('data-tab');

    activate(initial);
  });
})();
