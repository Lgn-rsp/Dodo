// LOGOS Wallet — Airdrop module REMOVED (2026-01-01)
// оставлено как безопасный stub, чтобы ничего не ломалось, если где-то осталась ссылка.
window.LOGOS_AIRDROP = { enabled: false };
