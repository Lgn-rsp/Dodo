(() => {
  const dict = {
    ru: {
      brand_sub: "Безопасный аккаунт-кошелёк для LGN и мультикрипты",
      tab_home: "Главная",
      tab_assets: "Активы",
      tab_staking: "Стейкинг",
      tab_card: "Карта",
      tab_settings: "Настройки",

      home_title: "Главная",
      home_sub: "Баланс, быстрые действия и операции",
      assets_title: "Активы",
      assets_sub: "Портфель, получение/отправка и история",
      staking_title: "Стейкинг",
      staking_sub: "LGN: stake / unstake / claim",
      card_title: "Карта",
      card_sub: "Spending pocket, лимиты и статусы",
      settings_title: "Настройки",
      settings_sub: "Безопасность, язык/тема, интеграции",

      rid_label: "RID",
      rid_missing: "RID не создан — нажми Create / Restore",
      btn_copy: "Копировать",
      btn_manage: "Создать / Восстановить",

      act_receive: "Получить",
      act_send: "Отправить",
      act_swap: "Обмен",
      act_fiat: "Фиат",
      act_stake: "Стейкинг",

      total_balance: "Общий баланс",
      view_usd: "В USD",
      view_eur: "В EUR",
      lgn_first: "LGN — основной актив",

      empty_need_rid: "Сначала создай/восстанови кошелёк (RID).",
      empty_api: "API пока не подключён. UI готов — подключим ручки следующим шагом.",

      m_receive_title: "Получить",
      m_send_title: "Отправить",
      m_swap_title: "Обмен",
      m_fiat_title: "Фиат",
      m_stake_title: "Стейкинг",

      ok_copied: "Скопировано",
      err_copy: "Не удалось скопировать",
      open_onboarding: "Открываю онбординг…"
    },
    en: {
      brand_sub: "Secure account-wallet for LGN & multi-assets",
      tab_home: "Home",
      tab_assets: "Assets",
      tab_staking: "Staking",
      tab_card: "Card",
      tab_settings: "Settings",

      home_title: "Home",
      home_sub: "Balance, quick actions and operations",
      assets_title: "Assets",
      assets_sub: "Portfolio, receive/send and history",
      staking_title: "Staking",
      staking_sub: "LGN: stake / unstake / claim",
      card_title: "Card",
      card_sub: "Spending pocket, limits and statuses",
      settings_title: "Settings",
      settings_sub: "Security, language/theme, integrations",

      rid_label: "RID",
      rid_missing: "RID not set — press Create / Restore",
      btn_copy: "Copy",
      btn_manage: "Create / Restore",

      act_receive: "Receive",
      act_send: "Send",
      act_swap: "Swap",
      act_fiat: "Fiat",
      act_stake: "Stake",

      total_balance: "Total balance",
      view_usd: "In USD",
      view_eur: "In EUR",
      lgn_first: "LGN is the primary asset",

      empty_need_rid: "Create/restore wallet first (RID).",
      empty_api: "API not connected yet. UI is ready — we'll plug endpoints next.",

      m_receive_title: "Receive",
      m_send_title: "Send",
      m_swap_title: "Swap",
      m_fiat_title: "Fiat",
      m_stake_title: "Staking",

      ok_copied: "Copied",
      err_copy: "Copy failed",
      open_onboarding: "Opening onboarding…"
    }
  };

  function getLang(){
    const v = (localStorage.getItem("logos_lang") || "ru").toLowerCase();
    return (v === "en") ? "en" : "ru";
  }

  window.I18N = {
    getLang,
    t(key){
      const lang = getLang();
      return (dict[lang] && dict[lang][key]) || (dict.ru[key] || key);
    },
    setLang(lang){
      const v = (String(lang||"").toLowerCase() === "en") ? "en" : "ru";
      localStorage.setItem("logos_lang", v);
    }
  };
})();
