"use strict";

(() => {
  const $ = (q, el=document) => el.querySelector(q);
  const $$ = (q, el=document) => Array.from(el.querySelectorAll(q));

  function normalize(u){ return (u||"").toString().trim().replace(/\/+$/,""); }

  // ===== THEME / LANG =====
  function applyTheme(){
    const t = localStorage.getItem("logos_theme") || "dark";
    document.documentElement.dataset.theme = (t === "light") ? "light" : "dark";
  }
  function toggleTheme(){
    const cur = document.documentElement.dataset.theme || "dark";
    const next = (cur === "dark") ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("logos_theme", next);
    toast("Theme: " + next);
  }

  function applyLang(){
    const lang = I18N.getLang();
    $("#btnLang").textContent = lang.toUpperCase();
    $("#brandSub").textContent = I18N.t("brand_sub");

    $$("[data-i18n]").forEach(el=>{
      const k = el.getAttribute("data-i18n");
      el.textContent = I18N.t(k);
    });

    // current page titles will be re-rendered by setTab()
  }
  function toggleLang(){
    const cur = I18N.getLang();
    const next = (cur === "ru") ? "en" : "ru";
    I18N.setLang(next);
    applyLang();
    render();
  }

  // ===== RID STORAGE (compat with your old keys) =====
  function getRid(){
    try{
      const a = JSON.parse(localStorage.getItem("logos_onb_v1") || "{}");
      if (a && a.rid) return String(a.rid);
    }catch(_){}
    const rid = localStorage.getItem("logos_rid") || localStorage.getItem("RID") || "";
    return String(rid || "");
  }

  function setRid(rid){
    const r = String(rid||"").trim();
    if (!r) return;
    localStorage.setItem("logos_rid", r);
    localStorage.setItem("RID", r);
  }

  async function copyText(text){
    try{
      await navigator.clipboard.writeText(String(text||""));
      toast(I18N.t("ok_copied"));
      return true;
    }catch(_){
      toast(I18N.t("err_copy"));
      return false;
    }
  }

  // ===== API BASE =====
  function apiBase(){
    // IMPORTANT: we keep same paths you already have on domain
    const origin = normalize(window.location.origin);
    return {
      node: origin + "/node-api",
      wallet: origin + "/wallet-api"
    };
  }

  async function fetchJson(url, opts={}, timeoutMs=6000){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeoutMs);
    try{
      const res = await fetch(url, { ...opts, signal: ctrl.signal, cache: "no-store" });
      const ct = res.headers.get("content-type") || "";
      const txt = await res.text();
      if (!res.ok) throw new Error("HTTP " + res.status + " " + txt.slice(0,140));
      if (ct.includes("application/json")) return JSON.parse(txt);
      // allow plain text
      return { ok:true, text: txt };
    } finally {
      clearTimeout(t);
    }
  }

  // ===== UI helpers =====
  let toastTimer = null;
  function toast(msg){
    const el = $("#toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=>el.classList.remove("show"), 1800);
  }

  function modalOpen(title, bodyHtml, footHtml=""){
    $("#modalTitle").textContent = title;
    $("#modalBody").innerHTML = bodyHtml;
    $("#modalFoot").innerHTML = footHtml;
    $("#modal").setAttribute("aria-hidden","false");
  }
  function modalClose(){
    $("#modal").setAttribute("aria-hidden","true");
  }

  // ===== STATUS pills =====
  async function updateStatus(){
    const base = apiBase();
    const rid = getRid();

    // NODE
    try{
      const j = await fetchJson(base.node + "/healthz");
      $("#pillNode").textContent = (j && j.status === "ok") ? "NODE: ON" : "NODE: ?";
      $("#pillNode").style.borderColor = (j && j.status === "ok") ? "rgba(34,197,94,.55)" : "";
    }catch(_){
      $("#pillNode").textContent = "NODE: OFF";
      $("#pillNode").style.borderColor = "rgba(248,113,113,.55)";
    }

    // WALLET
    if (!rid){
      $("#pillWallet").textContent = "WALLET: —";
      $("#pillWallet").style.borderColor = "";
      return;
    }
    try{
      // health endpoint may not exist; we still show OK if RID exists
      await fetchJson(base.wallet + "/healthz").catch(()=>null);
      $("#pillWallet").textContent = "WALLET: OK";
      $("#pillWallet").style.borderColor = "rgba(79,124,255,.55)";
    }catch(_){
      $("#pillWallet").textContent = "WALLET: OK";
      $("#pillWallet").style.borderColor = "rgba(79,124,255,.55)";
    }
  }

  // ===== RENDER =====
  const state = { tab: "home" };

  function setTab(tab){
    state.tab = tab;
    $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    render();
  }

  function renderHeader(){
    const rid = getRid();
    $("#ridLabel").textContent = I18N.t("rid_label");
    $("#ridValue").textContent = rid ? rid : I18N.t("rid_missing");
    $("#btnCopyRid").textContent = I18N.t("btn_copy");
    $("#btnManageRid").textContent = I18N.t("btn_manage");
  }

  function viewHome(){
    $("#pageTitle").textContent = I18N.t("home_title");
    $("#pageSub").textContent = I18N.t("home_sub");

    const rid = getRid();

    const actions = `
      <div class="actions">
        <button class="btn primary" id="actReceive">${I18N.t("act_receive")}</button>
        <button class="btn" id="actSend">${I18N.t("act_send")}</button>
        <button class="btn" id="actSwap">${I18N.t("act_swap")}</button>
        <button class="btn" id="actFiat">${I18N.t("act_fiat")}</button>
        <button class="btn success" id="actStake">${I18N.t("act_stake")}</button>
      </div>
    `;

    const content = `
      <div class="grid two">
        <div class="card">
          <div class="cardIn">
            <div class="row">
              <div>
                <div class="cardTitle">${I18N.t("total_balance")}</div>
                <div class="cardSub">${I18N.t("lgn_first")}</div>
              </div>
              <div class="badge mono" id="currencyBadge">LGN</div>
            </div>

            <div class="row" style="align-items:flex-end">
              <div class="bigAmount" id="totalAmount">—</div>
              <div class="actions" style="margin:0">
                <button class="btn ghost" id="viewUSD">${I18N.t("view_usd")}</button>
                <button class="btn ghost" id="viewEUR">${I18N.t("view_eur")}</button>
              </div>
            </div>

            ${rid ? "" : `<div class="empty">${I18N.t("empty_need_rid")}</div>`}
            ${actions}
          </div>
        </div>

        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">Activity</div>
            <div class="cardSub">History & notifications (next step)</div>
            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>
      </div>
    `;

    $("#content").innerHTML = content;

    // set mock total
    $("#totalAmount").textContent = rid ? "0.00" : "—";

    $("#actReceive").onclick = () => openReceive();
    $("#actSend").onclick = () => openSend();
    $("#actSwap").onclick = () => openSwap();
    $("#actFiat").onclick = () => openFiat();
    $("#actStake").onclick = () => setTab("staking");

    $("#viewUSD").onclick = () => {
      $("#currencyBadge").textContent = "USD";
      $("#totalAmount").textContent = rid ? "0.00" : "—";
    };
    $("#viewEUR").onclick = () => {
      $("#currencyBadge").textContent = "EUR";
      $("#totalAmount").textContent = rid ? "0.00" : "—";
    };
  }

  function viewAssets(){
    $("#pageTitle").textContent = I18N.t("assets_title");
    $("#pageSub").textContent = I18N.t("assets_sub");

    const rid = getRid();
    const list = `
      <div class="list">
        <div class="item">
          <div class="itL">
            <div class="coin"></div>
            <div>
              <div class="sym">LGN</div>
              <div class="name">LOGOS Network</div>
            </div>
          </div>
          <div class="itR">
            <div class="val">0.00</div>
            <div class="small">≈ 0.00 USD</div>
          </div>
        </div>

        <div class="item">
          <div class="itL">
            <div class="coin" style="background: radial-gradient(10px 10px at 30% 30%, rgba(255,255,255,.55), transparent 65%), linear-gradient(135deg, rgba(34,197,94,.35), rgba(79,124,255,.25));"></div>
            <div>
              <div class="sym">USDT</div>
              <div class="name">Tether (bridge)</div>
            </div>
          </div>
          <div class="itR">
            <div class="val">0.00</div>
            <div class="small">≈ 0.00 USD</div>
          </div>
        </div>

        <div class="item">
          <div class="itL">
            <div class="coin" style="background: radial-gradient(10px 10px at 30% 30%, rgba(255,255,255,.55), transparent 65%), linear-gradient(135deg, rgba(251,191,36,.35), rgba(147,51,234,.25));"></div>
            <div>
              <div class="sym">BTC</div>
              <div class="name">Bitcoin (bridge)</div>
            </div>
          </div>
          <div class="itR">
            <div class="val">0.00</div>
            <div class="small">≈ 0.00 USD</div>
          </div>
        </div>
      </div>
    `;

    $("#content").innerHTML = `
      <div class="card">
        <div class="cardIn">
          <div class="row" style="margin-top:0">
            <div>
              <div class="cardTitle">Portfolio</div>
              <div class="cardSub">LGN first • multi-assets next</div>
            </div>
            <div class="actions" style="margin:0">
              <button class="btn primary" id="btnReceive">${I18N.t("act_receive")}</button>
              <button class="btn" id="btnSend">${I18N.t("act_send")}</button>
            </div>
          </div>

          ${rid ? "" : `<div class="empty">${I18N.t("empty_need_rid")}</div>`}
          ${list}
          <div class="empty">${I18N.t("empty_api")}</div>
        </div>
      </div>
    `;

    $("#btnReceive").onclick = () => openReceive();
    $("#btnSend").onclick = () => openSend();
  }

  function viewStaking(){
    $("#pageTitle").textContent = I18N.t("staking_title");
    $("#pageSub").textContent = I18N.t("staking_sub");

    const rid = getRid();
    $("#content").innerHTML = `
      <div class="grid two">
        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">LGN Staking</div>
            <div class="cardSub">Stake • Unstake • Claim • Auto-compound (next)</div>

            ${rid ? "" : `<div class="empty">${I18N.t("empty_need_rid")}</div>`}

            <div class="row">
              <div>
                <div class="small">Staked</div>
                <div class="val" style="font-size:22px">0.00 LGN</div>
              </div>
              <div>
                <div class="small">Rewards</div>
                <div class="val" style="font-size:22px">0.00 LGN</div>
              </div>
            </div>

            <div class="row">
              <div class="badge">APR: —</div>
              <div class="badge">Unbonding: —</div>
            </div>

            <div class="actions">
              <button class="btn success" id="btnStake">Stake</button>
              <button class="btn" id="btnUnstake">Unstake</button>
              <button class="btn primary" id="btnClaim">Claim</button>
            </div>

            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>

        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">Validators</div>
            <div class="cardSub">Choose validator • delegation stats (next)</div>
            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>
      </div>
    `;

    $("#btnStake").onclick = () => openStake();
    $("#btnUnstake").onclick = () => openStake("unstake");
    $("#btnClaim").onclick = () => openStake("claim");
  }

  function viewCard(){
    $("#pageTitle").textContent = I18N.t("card_title");
    $("#pageSub").textContent = I18N.t("card_sub");

    $("#content").innerHTML = `
      <div class="grid two">
        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">LOGOS Card</div>
            <div class="cardSub">Premium spending layer (fiat integration later)</div>

            <div class="row">
              <div>
                <div class="small">Spending pocket</div>
                <div class="val" style="font-size:26px">0.00</div>
              </div>
              <div class="badge">KYC: —</div>
            </div>

            <div class="actions">
              <button class="btn primary" id="btnTopupPocket">Top up</button>
              <button class="btn" id="btnLimits">Limits</button>
              <button class="btn ghost" id="btnHistory">History</button>
            </div>

            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>

        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">Security</div>
            <div class="cardSub">Anti-fraud • time-lock • address whitelist (next)</div>
            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>
      </div>
    `;

    $("#btnTopupPocket").onclick = () => openFiat();
    $("#btnLimits").onclick = () => openFiat();
    $("#btnHistory").onclick = () => openFiat();
  }

  function viewSettings(){
    $("#pageTitle").textContent = I18N.t("settings_title");
    $("#pageSub").textContent = I18N.t("settings_sub");

    $("#content").innerHTML = `
      <div class="grid two">
        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">Security</div>
            <div class="cardSub">Seed control • passphrase • passkey (next)</div>

            <div class="actions">
              <button class="btn" id="btnSeed">Seed check</button>
              <button class="btn" id="btnPasskey">Passkey</button>
              <button class="btn" id="btnLimits2">Limits</button>
            </div>
            <div class="empty">${I18N.t("empty_api")}</div>
          </div>
        </div>

        <div class="card">
          <div class="cardIn">
            <div class="cardTitle">About</div>
            <div class="cardSub">Version • endpoints • diagnostics</div>

            <div class="list">
              <div class="item">
                <div class="itL"><div class="sym">Node API</div></div>
                <div class="itR"><div class="small mono" id="aboutNode">—</div></div>
              </div>
              <div class="item">
                <div class="itL"><div class="sym">Wallet API</div></div>
                <div class="itR"><div class="small mono" id="aboutWallet">—</div></div>
              </div>
            </div>

            <div class="actions">
              <button class="btn primary" id="btnDiag">Diagnostics</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const base = apiBase();
    $("#aboutNode").textContent = base.node;
    $("#aboutWallet").textContent = base.wallet;

    $("#btnDiag").onclick = () => openDiag();
    $("#btnSeed").onclick = () => openOnboarding();
    $("#btnPasskey").onclick = () => openDiag();
    $("#btnLimits2").onclick = () => openDiag();
  }

  function render(){
    renderHeader();
    const tab = state.tab;
    if (tab === "home") return viewHome();
    if (tab === "assets") return viewAssets();
    if (tab === "staking") return viewStaking();
    if (tab === "card") return viewCard();
    if (tab === "settings") return viewSettings();
    viewHome();
  }

  // ===== Modals =====
  function openReceive(){
    const rid = getRid();
    if (!rid) return openOnboarding();
    modalOpen(I18N.t("m_receive_title"),
      `
      <div class="label">Asset</div>
      <select class="input" id="mAsset">
        <option>LGN</option>
        <option>USDT</option>
        <option>BTC</option>
      </select>
      <div class="label">Address / RID</div>
      <input class="input mono" value="${rid}" readonly/>
      <div class="hr"></div>
      <div class="empty">${I18N.t("empty_api")}</div>
      `,
      `<button class="btn primary" id="mCopy">Copy</button><button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mCopy").onclick = () => copyText(rid);
    $("#mClose").onclick = () => modalClose();
  }

  function openSend(){
    const rid = getRid();
    if (!rid) return openOnboarding();
    modalOpen(I18N.t("m_send_title"),
      `
      <div class="label">To (RID / address)</div>
      <input class="input mono" id="toRid" placeholder="RID..."/>
      <div class="label">Amount (LGN)</div>
      <input class="input" id="amt" placeholder="0.00"/>
      <div class="hr"></div>
      <div class="empty">${I18N.t("empty_api")}</div>
      `,
      `<button class="btn primary" id="mSubmit">Sign & send</button><button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mSubmit").onclick = () => toast("Next step: connect /withdraw + intent-sign");
    $("#mClose").onclick = () => modalClose();
  }

  function openSwap(){
    const rid = getRid();
    if (!rid) return openOnboarding();
    modalOpen(I18N.t("m_swap_title"),
      `
      <div class="label">From</div>
      <select class="input"><option>LGN</option><option>USDT</option></select>
      <div class="label">To</div>
      <select class="input"><option>USDT</option><option>LGN</option></select>
      <div class="label">Amount</div>
      <input class="input" placeholder="0.00"/>
      <div class="hr"></div>
      <div class="empty">${I18N.t("empty_api")}</div>
      `,
      `<button class="btn primary" id="mSwap">Continue</button><button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mSwap").onclick = () => toast("Next step: bridge/swap endpoints");
    $("#mClose").onclick = () => modalClose();
  }

  function openFiat(){
    modalOpen(I18N.t("m_fiat_title"),
      `
      <div class="cardSub">SEPA / cards / KYC — after integration</div>
      <div class="empty">${I18N.t("empty_api")}</div>
      `,
      `<button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mClose").onclick = () => modalClose();
  }

  function openStake(mode="stake"){
    const rid = getRid();
    if (!rid) return openOnboarding();
    const title = (mode==="claim") ? "Claim" : (mode==="unstake" ? "Unstake" : I18N.t("m_stake_title"));
    modalOpen(title,
      `
      <div class="label">Amount (LGN)</div>
      <input class="input" placeholder="0.00"/>
      <div class="label">Validator</div>
      <input class="input mono" placeholder="validator RID / key"/>
      <div class="hr"></div>
      <div class="empty">${I18N.t("empty_api")}</div>
      `,
      `<button class="btn primary" id="mDo">Continue</button><button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mDo").onclick = () => toast("Next step: staking endpoints (delegate/undelegate/claim)");
    $("#mClose").onclick = () => modalClose();
  }

  function openDiag(){
    const base = apiBase();
    modalOpen("Diagnostics",
      `
      <div class="label">Node API</div>
      <input class="input mono" value="${base.node}" readonly/>
      <div class="label">Wallet API</div>
      <input class="input mono" value="${base.wallet}" readonly/>
      <div class="hr"></div>
      <div class="empty">UI is premium-ready. Next step: connect balance/history/topup/withdraw/staking.</div>
      `,
      `<button class="btn primary" id="mPing">Ping node</button><button class="btn ghost" id="mClose">Close</button>`
    );
    $("#mPing").onclick = async () => {
      try{
        const j = await fetchJson(base.node + "/healthz");
        toast("node: " + (j.status || "ok"));
      }catch(e){
        toast("node: OFF");
      }
    };
    $("#mClose").onclick = () => modalClose();
  }

  function openOnboarding(){
    toast(I18N.t("open_onboarding"));
    // Пока просто перекидываем на твой онбординг путь (можно заменить на SPA-экран)
    // Если у тебя другой путь — поменяем тут одной строкой.
    window.location.href = "/wallet_dev/welcome.html";
  }

  // ===== INIT =====
  function bind(){
    $("#btnTheme").onclick = toggleTheme;
    $("#btnLang").onclick = toggleLang;

    $("#btnCopyRid").onclick = () => {
      const rid = getRid();
      if (!rid) return toast(I18N.t("empty_need_rid"));
      copyText(rid);
    };
    $("#btnManageRid").onclick = openOnboarding;

    $$(".tab").forEach(b => b.onclick = () => setTab(b.dataset.tab));

    $("#modalBack").onclick = modalClose;
    $("#modalClose").onclick = modalClose;

    // default tab
    const hash = (location.hash || "").replace("#","");
    if (hash) state.tab = hash;
  }

  function boot(){
    applyTheme();
    applyLang();
    bind();
    render();
    updateStatus();
    setInterval(updateStatus, 7000);
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
